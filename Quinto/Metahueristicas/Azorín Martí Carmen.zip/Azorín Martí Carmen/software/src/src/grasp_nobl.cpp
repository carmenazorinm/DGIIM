#include "grasp_nobl.h"
#include <algorithm>
#include <unordered_map>
#include <cstdlib>
#include <limits>
#include <iostream>

ResultMH GRASP_NOBL::optimize(Problem *problem, int maxevals)
{
    Snimp *snimp = static_cast<Snimp *>(problem);
    int evals_total = 0;

    tSolution bestSol;
    tFitness bestFitness = std::numeric_limits<tFitness>::lowest();

    for (int i = 0; i < 10 && evals_total < maxevals; ++i)
    {
        // if (evals_total % 1 == 0)
        //     cout << "Eval: " << evals_total << "Mejor fitness GRASP_NOBL: " << bestFitness << endl;
        tSolution sol = construirGreedyAleatorizado(snimp);
        tFitness fit = snimp->fitness(sol);
        ++evals_total;

        if (fit > bestFitness)
        {
            bestFitness = fit;
            bestSol = sol;
        }
    }

    return ResultMH(bestSol, bestFitness, evals_total);
}

tSolution GRASP_NOBL::construirGreedyAleatorizado(Snimp *snimp)
{
    vector<int> todos = snimp->nodos();
    size_t m = snimp->getSolutionSize();

    std::random_shuffle(todos.begin(), todos.end());
    tSolution sel = {todos[0]};
    todos.erase(todos.begin());

    while (sel.size() < m)
    {
        unordered_map<int, float> heur;
        float heurMax = -1e9, heurMin = 1e9;

        for (int nodo : todos)
        {
            float h = snimp->heuristic(nodo);
            heur[nodo] = h;
            heurMax = std::max(heurMax, h);
            heurMin = std::min(heurMin, h);
        }

        float umbral = heurMax - ((float)rand() / RAND_MAX) * (heurMax - heurMin);
        vector<int> LRC;
        for (const auto &[nodo, h] : heur)
            if (h >= umbral)
                LRC.push_back(nodo);

        int elegido = LRC[rand() % LRC.size()];
        sel.push_back(elegido);
        todos.erase(std::remove(todos.begin(), todos.end(), elegido), todos.end());
    }

    return sel;
}
