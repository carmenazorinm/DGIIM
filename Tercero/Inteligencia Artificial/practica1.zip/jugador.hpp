#ifndef COMPORTAMIENTOJUGADOR_H
#define COMPORTAMIENTOJUGADOR_H

#include "comportamientos/comportamiento.hpp"
using namespace std;

struct state {
  int fil;
  int col;
  Orientacion brujula;
  bool lleva_bikini;
  bool lleva_zapas;
};

class ComportamientoJugador : public Comportamiento{

  public:
    ComportamientoJugador(unsigned int size) : Comportamiento(size){
      // Constructor de la clase
      current_state.fil = size;
      current_state.col = size;
      current_state.brujula = norte;
      current_state.lleva_bikini = false;
      current_state.lleva_zapas = false;
      last_action = actIDLE;
      girar_derecha = false;
      bien_situado = false;
      // Dar el valor inicial a las variables de estado

      // ESTO ES MIO
      ha_girado = false;
      
      for(int i = 0; i < mapaResultado.size(); i++) {
        vector<int> v(mapaResultado.at(0).size(),0);
        vecesPosicionado.push_back(v);
      }

      for(int i = 0; i < mapaResultado.size()*2; i++) {
        vector<int> v(mapaResultado.at(0).size()*2,0);
        vecesPosicionadoProv.push_back(v);
      }
      buscando_recarga = false;
      ha_andado = false; // para buscar recarga que avance
      girado_izquierda = false;
      girado_derecha = false;
      pasos_sin_recargar = 1500;
      numero_giros = 0;
      buscando_zapas = false;
      buscando_bikini = false;
      sigue_recargando = false;
      rodeado = false;
      pos_salida.push_back(-1);
      pos_salida.push_back(-1);
      en_muro = 0;
      esquinas_vistas = 0;
      sal_muro = false;
      long_muro = 0;
      midiendo_muro = false;
      busca_recarga = false;
      recarga_cercana = 0;
      hay_obstaculo = false;

      for(int i = 0; i < mapaResultado.size()*2; i++) {
        vector<unsigned char> v(mapaResultado.at(0).size()*2,'?');
        mapaProv.push_back(v);
      }
      stProv.fil = mapaResultado.size();
      stProv.col = mapaResultado.size();
      stProv.brujula = (Orientacion) 0;
      stProv.lleva_bikini = false;
      stProv.lleva_zapas = false;
      empiezaEnMuro = false;
      busca_salida = false;
      antes_pegado = -1;
      avanza = false;
      empieza_rodeado = false;
      buscando_pos = false;
      veces_comprobado = 0;
    }

    ComportamientoJugador(const ComportamientoJugador & comport) : Comportamiento(comport){}
    ~ComportamientoJugador(){}

    Action think(Sensores sensores);
    int interact(Action accion, int valor);

  private:

  // Declarar aquí las variables de estado

  // recordar dónde estoy y hacía dónde voy a dar mi siguiente paso
  state current_state;
  //  realizar la actualización de la información y recordar cuál fue la última acción
  Action last_action;

  bool girar_derecha;
  //nos dice si el valor de la variable current_state refleja la pos real
  bool bien_situado;

  // ESTO ES MIO
  bool ha_girado;
  vector < vector <int> > vecesPosicionado;
  vector<vector <int>> vecesPosicionadoProv;
  bool buscando_recarga;
  bool ha_andado;
  bool girado_izquierda;
  bool girado_derecha;
  int pasos_sin_recargar;
  int numero_giros;
  bool buscando_zapas;
  bool buscando_bikini;
  bool sigue_recargando;
  vector<int> filas_recarga;
  vector<int> cols_recarga;
  bool rodeado;
  vector<int> pos_salida;
  int en_muro;
  int esquinas_vistas; // esquinas vistas del muro
  bool sal_muro;
  int long_muro;
  bool midiendo_muro;
  bool busca_recarga;
  int recarga_cercana;
  bool hay_obstaculo;
  vector<vector<unsigned char>> mapaProv;
  int orientProv;
  int filaProv;
  int colProv;
  state stProv;
  bool empiezaEnMuro;
  bool busca_salida;
  bool avanza;
  int antes_pegado;
  bool empieza_rodeado;
  int veces_comprobado;
  bool buscando_pos;
};

#endif
