#include "../Comportamientos_Jugador/jugador.hpp"
#include <iostream>
using namespace std;

void PonerTerrenoEnMatriz(const vector<unsigned char> &terreno, const state &st,
													vector < vector <unsigned char> > &matriz) {
		matriz[st.fil][st.col] = terreno[0];
		int casilla = 0;
		if(st.brujula == norte) {
			matriz[st.fil-1][st.col-1] = terreno[1];
			matriz[st.fil-1][st.col] = terreno[2];
			matriz[st.fil-1][st.col+1] = terreno[3];
			matriz[st.fil-2][st.col-2] = terreno[4];
			matriz[st.fil-2][st.col-1] = terreno[5];
			matriz[st.fil-2][st.col] = terreno[6];
			matriz[st.fil-2][st.col+1] = terreno[7];
			matriz[st.fil-2][st.col+2] = terreno[8];
			matriz[st.fil-3][st.col-3] = terreno[9];
			matriz[st.fil-3][st.col-2] = terreno[10];
			matriz[st.fil-3][st.col-1] = terreno[11];
			matriz[st.fil-3][st.col] = terreno[12];
			matriz[st.fil-3][st.col+1] = terreno[13];
			matriz[st.fil-3][st.col+2] = terreno[14];
			matriz[st.fil-3][st.col+3] = terreno[15];
		} else if(st.brujula == sur) {
			for(int fila = 1; fila <= 3; fila++) {
				for(int columna = fila; columna >= -fila; columna--) {
					casilla++;
					matriz[st.fil + fila][st.col + columna] = terreno[casilla];
				}
			}
		} else if(st.brujula == este) {
			for(int columna = 1; columna <= 3; columna++) {
				for(int fila = -columna; fila <= columna; fila++) {
					casilla++;
					matriz[st.fil + fila][st.col + columna] = terreno[casilla];
				}
			}
		} else if(st.brujula == oeste) {
			for(int columna = -1; columna >= -3; columna--) {
				for(int fila = -columna; fila >= columna; fila--) {
					casilla++;
					matriz[st.fil + fila][st.col + columna] = terreno[casilla];
				}
			}
		} else if(st.brujula == noreste) {
			matriz[st.fil][st.col+1] = terreno[3];
			matriz[st.fil][st.col+2] = terreno[8];
			matriz[st.fil][st.col+3] = terreno[15];
			matriz[st.fil-1][st.col] = terreno[1];
			matriz[st.fil-1][st.col+1] = terreno[2];
			matriz[st.fil-1][st.col+2] = terreno[7];
			matriz[st.fil-1][st.col+3] = terreno[14];
			matriz[st.fil-2][st.col] = terreno[4];
			matriz[st.fil-2][st.col+1] = terreno[5];
			matriz[st.fil-2][st.col+2] = terreno[6];
			matriz[st.fil-2][st.col+3] = terreno[13];
			matriz[st.fil-3][st.col] = terreno[9];
			matriz[st.fil-3][st.col+1] = terreno[10];
			matriz[st.fil-3][st.col+2] = terreno[11];
			matriz[st.fil-3][st.col+3] = terreno[12];
		} else if(st.brujula == sureste) {
			matriz[st.fil][st.col+1] = terreno[1];
			matriz[st.fil][st.col+2] = terreno[4];
			matriz[st.fil][st.col+3] = terreno[9];
			matriz[st.fil+1][st.col] = terreno[3];
			matriz[st.fil+1][st.col+1] = terreno[2];
			matriz[st.fil+1][st.col+2] = terreno[5];
			matriz[st.fil+1][st.col+3] = terreno[10];
			matriz[st.fil+2][st.col] = terreno[8];
			matriz[st.fil+2][st.col+1] = terreno[7];
			matriz[st.fil+2][st.col+2] = terreno[6];
			matriz[st.fil+2][st.col+3] = terreno[11];
			matriz[st.fil+3][st.col] = terreno[15];
			matriz[st.fil+3][st.col+1] = terreno[14];
			matriz[st.fil+3][st.col+2] = terreno[13];
			matriz[st.fil+3][st.col+3] = terreno[12];
		} else if (st.brujula == suroeste) {
			matriz[st.fil][st.col-1] = terreno[3];
			matriz[st.fil][st.col-2] = terreno[8];
			matriz[st.fil][st.col-3] = terreno[15];
			matriz[st.fil+1][st.col] = terreno[1];
			matriz[st.fil+1][st.col-1] = terreno[2];
			matriz[st.fil+1][st.col-2] = terreno[7];
			matriz[st.fil+1][st.col-3] = terreno[14];
			matriz[st.fil+2][st.col] = terreno[4];
			matriz[st.fil+2][st.col-1] = terreno[5];
			matriz[st.fil+2][st.col-2] = terreno[6];
			matriz[st.fil+2][st.col-3] = terreno[13];
			matriz[st.fil+3][st.col] = terreno[9];
			matriz[st.fil+3][st.col-1] = terreno[10];
			matriz[st.fil+3][st.col-2] = terreno[11];
			matriz[st.fil+3][st.col-3] = terreno[12];
		} else if(st.brujula == noroeste) {
			matriz[st.fil][st.col-1] = terreno[1];
			matriz[st.fil][st.col-2] = terreno[4];
			matriz[st.fil][st.col-3] = terreno[9];
			matriz[st.fil-1][st.col] = terreno[3];
			matriz[st.fil-1][st.col-1] = terreno[2];
			matriz[st.fil-1][st.col-2] = terreno[5];
			matriz[st.fil-1][st.col-3] = terreno[10];
			matriz[st.fil-2][st.col] = terreno[8];
			matriz[st.fil-2][st.col-1] = terreno[7];
			matriz[st.fil-2][st.col-2] = terreno[6];
			matriz[st.fil-2][st.col-3] = terreno[11];
			matriz[st.fil-3][st.col] = terreno[15];
			matriz[st.fil-3][st.col-1] = terreno[14];
			matriz[st.fil-3][st.col-2] = terreno[13];
			matriz[st.fil-3][st.col-3] = terreno[12];
		}
}

bool sin_diagonal(Orientacion a) {
	return a == norte || a == sur || a == oeste || a == este;
}

void trasladarMatrizMR(vector<vector<unsigned char>> &aux,vector<vector<unsigned char>> &orig,const state &staux,state &storig) {
	if(aux[staux.fil][staux.col] == 'G') {
		int f,c;

		for(int i = 0; i < orig.size(); i++) {
			for(int j = 0; j < orig.at(i).size(); j++) {
				if(orig[i][j] == '?') {
					f = staux.fil - storig.fil + i;
					c = staux.col - storig.col +j;
					orig[i][j] = aux[f][c];
				}
			}
		}
	}
	
}

void trasladarMatrizVP(vector<vector<int>> &aux,vector<vector<int>> &orig,const state &staux,state &storig) {
	if(aux[staux.fil][staux.col] == 'G') {
		int f,c;

		for(int i = 0; i < orig.size(); i++) {
			for(int j = 0; j < orig.at(i).size(); j++) {
				f = staux.fil - storig.fil + i;
				c = staux.col - storig.col +j;
				orig[i][j] = aux[f][c];
			}
		}
	}
}

void rellenarPrecipicios(vector < vector <unsigned char> > &matriz) {
	int size = matriz.size();
	for(int i = 0; i < size; i++) {
		for(int j = 0; j < 3; j++) {
			matriz[i][j] = 'P';
			matriz[size-i-1][size-j-1] = 'P';
			matriz[j][i] = 'P';
			matriz[size-j-1][size-i-1] = 'P';
		}
	}

}

bool terrenoAccesible(Sensores sensores, int casilla,const state &st) {
	bool accesible;
	if(st.lleva_bikini && !st.lleva_zapas) {
		accesible = (sensores.terreno[casilla]=='T' or sensores.terreno[casilla]=='S' or sensores.terreno[casilla]=='X' 
			or sensores.terreno[casilla]== 'G'  or sensores.terreno[casilla]=='D' or sensores.terreno[casilla]=='K' or sensores.terreno[casilla] == 'A')
			and sensores.superficie[casilla]=='_';
	}else if(st.lleva_zapas && !st.lleva_bikini) {
		accesible = (sensores.terreno[casilla]=='T' or sensores.terreno[casilla]=='S' or sensores.terreno[casilla]=='X'
			or sensores.terreno[casilla]== 'G'  or sensores.terreno[casilla]=='D' or sensores.terreno[casilla]=='K' or sensores.terreno[casilla] == 'B')
			and sensores.superficie[casilla]=='_';
	} else if(!st.lleva_zapas && !st.lleva_bikini){
		accesible = (sensores.terreno[casilla]=='T' or sensores.terreno[casilla]=='S' or sensores.terreno[casilla]=='X'
			or sensores.terreno[casilla]== 'G'  or sensores.terreno[casilla]=='D'  or sensores.terreno[casilla]=='K')
			and sensores.superficie[casilla]=='_';
	} else {
		accesible = (sensores.terreno[casilla]=='T' or sensores.terreno[casilla]=='S' or sensores.terreno[casilla]=='X'
			or sensores.terreno[casilla]== 'G'  or sensores.terreno[casilla]=='D'  or sensores.terreno[casilla]=='K' or sensores.terreno[casilla] == 'A' or
			sensores.terreno[casilla] == 'B')
			and sensores.superficie[casilla]=='_';
	}

	return accesible;
}

int sacar_cols_recarga(int pos, state&st) {
	int r = 0;
	if(st.brujula == norte) {
		if(pos == 15) r = 3;
		else if(pos == 14 or pos == 8 ) r = +2;
		else if(pos == 3 or pos == 7 or pos == 13) r = 1;
		else if(pos == 1 or pos == 5 or pos == 11 ) r = -1;
		else if(pos == 4 or pos == 10) r = -2;
		else if (pos == 9) r = -3;
		else r = 0;
	} else if(st.brujula == noreste) {
		if(pos == 1 or pos == 4 or pos == 9) r = 0;
		else if(pos == 10 or pos == 5 or pos == 2 or pos == 3) r = 1;
		else if(pos == 11 or pos == 6 or pos == 7 or pos == 8) r = 2;
		else r = 3;
	} else if(st.brujula == este) {
		if (pos >= 1 and pos <= 3) r = 1;
		else if(pos >= 4 and pos < 9) r = 2;
		else r = 3;
	} else if(st.brujula == sureste) {
		if(pos == 3 or pos == 8 or pos == 15) r = 0;
		else if(pos == 1 or pos == 2 or pos == 7 or pos == 14) r = 1;
		else if(pos == 4 or pos == 5 or pos == 6 or pos == 13) r = 2;
		else r = 3;
	} else if(st.brujula == sur) {
		if(pos == 15) r = -3;
		else if(pos == 14 or pos == 8 ) r = -2;
		else if(pos == 3 or pos == 7 or pos == 13) r = -1;
		else if(pos == 1 or pos == 5 or pos == 11 ) r = 1;
		else if(pos == 4 or pos == 10) r = 2;
		else if (pos == 9) r = 3;
		else r = 0;
	} else if(st.brujula == suroeste) {
		if(pos == 1 or pos == 4 or pos == 9) r = 0;
		else if(pos == 10 or pos == 5 or pos == 2 or pos == 3) r = -1;
		else if(pos == 11 or pos == 6 or pos == 7 or pos == 8) r = -2;
		else r = -3;
	} else if(st.brujula == oeste) {
		if (pos >= 1 and pos <= 3) r = -1;
		else if(pos >= 4 and pos < 9) r = -2;
		else r = -3;
	} else if(st.brujula == noroeste) {
		if(pos == 3 or pos == 8 or pos == 15) r = 0;
		else if(pos == 1 or pos == 2 or pos == 7 or pos == 14) r = -1;
		else if(pos == 4 or pos == 5 or pos == 6 or pos == 13) r = -2;
		else r = -3;
	}
	return r;
}

int sacar_filas_recarga(int pos, state &st) {
	int r = 0;
	if(st.brujula == norte) {
		if (pos >= 1 and pos <= 3) r = -1;
		else if(pos >= 4 and pos < 9) r = -2;
		else r = -3;
	} else if (st.brujula == noreste) {
		if(pos == 3 or pos == 8 or pos == 15) r = 0;
		else if(pos == 1 or pos == 2 or pos == 7 or pos == 14) r = -1;
		else if(pos == 4 or pos == 5 or pos == 6 or pos == 13) r = -2;
		else r = -3;
	} else if(st.brujula == este) {
		if(pos == 15) r = 3;
		else if(pos == 14 or pos == 8 ) r = +2;
		else if(pos == 3 or pos == 7 or pos == 13) r = 1;
		else if(pos == 1 or pos == 5 or pos == 11 ) r = -1;
		else if(pos == 4 or pos == 10) r = -2;
		else if (pos == 9) r = -3;
		else r = 0;
	} else if(st.brujula == sureste) {
		if(pos ==1 or pos == 4 or pos == 9 ) r = 0;
		else if(pos == 3 or pos == 2 or pos == 5 or pos == 10) r = 1;
		else if(pos == 8 or pos == 7 or pos == 6 or pos == 11) r = 2;
		else r = 3;
	} else if(st.brujula == sur) {
		if(pos >0 and pos < 3) r = 1;
		else if (pos > 3 and pos< 9) r = 2;
		else r = 3;
	} else if(st.brujula == suroeste) {
		if (pos == 3 or pos == 8 or pos == 15) r = 0;
		else if (pos ==1 or pos == 2 or pos == 7 or pos == 14) r = 1;
		else if (pos == 4 or pos == 5 or pos == 6 or pos == 13) r = 2;
		else r = 3;
	} else if(st.brujula == oeste){
		if(pos == 15) r = -3;
		else if(pos == 14 or pos == 8 ) r = -2;
		else if(pos == 3 or pos == 7 or pos == 13) r = -1;
		else if(pos == 1 or pos == 5 or pos == 11 ) r = 1;
		else if(pos == 4 or pos == 10) r = 2;
		else if (pos == 9) r = 3;
		else r = 0;
	} else if(st.brujula == noroeste) {
		if(pos == 1 or pos == 4 or pos == 9) r = 0;
		else if(pos ==2 or pos == 3 or pos == 5 or pos == 10) r = -1;
		else if(pos ==6 or pos == 7 or pos == 8 or pos == 11) r = -2;
		else r = -3;
	}
	return r;
}

void actualizarVecesPosicionado(vector < vector <int> > &matriz, state &st, Sensores sensores) {
	switch(st.brujula) {
		case norte: matriz[st.fil-1][st.col]++; break;
		case noreste: matriz[st.fil-1][st.col+1]++; break;
		case este: matriz[st.fil][st.col+1]++; break;
		case sureste: matriz[st.fil+1][st.col+1]++; break;
		case sur: matriz[st.fil+1][st.col]++; break;
		case suroeste: matriz[st.fil+1][st.col-1]++; break;
		case oeste: matriz[st.fil][st.col-1]++; break;
		case noroeste: matriz[st.fil-1][st.col-1]++; break;
	}
	if(sensores.terreno[2] == 'D') {
		st.lleva_zapas = true;
	} else if(sensores.terreno[2] == 'K') {
		st.lleva_bikini = true;
	}
}

int se_ve_posicionamiento(Sensores sensores){
	int pos = -1;
	for(int i = 0; i < sensores.terreno.size() && pos==-1; i++) {
		if(sensores.terreno[i] == 'G') {
			pos = i;
		}
	}

	return pos;
}

int vecesPosicionadoEn(int n,vector < vector <int> > &matriz,const state &st) {
	int veces = 0;
	if(n == 1) {
		switch(st.brujula) {
			case norte: veces = matriz[st.fil-1][st.col-1]; break;
			case noreste: veces = matriz[st.fil-1][st.col]; break;
			case este: veces = matriz[st.fil-1][st.col+1]; break;
			case sureste: veces = matriz[st.fil][st.col+1]; break;
			case sur: veces = matriz[st.fil+1][st.col+1]; break;
			case suroeste: veces = matriz[st.fil+1][st.col]; break;
			case oeste: veces = matriz[st.fil+1][st.col-1]; break;
			case noroeste: veces = matriz[st.fil][st.col-1]; break;
		}
	}else if(n == 4) {
			switch(st.brujula) {
				case norte: veces = matriz[st.fil-2][st.col-2]; break;
				case noreste: veces = matriz[st.fil-2][st.col]; break;
				case este: veces = matriz[st.fil-2][st.col+2]; break;
				case sureste: veces = matriz[st.fil][st.col+2]; break;
				case sur: veces = matriz[st.fil+2][st.col+2]; break;
				case suroeste: veces = matriz[st.fil+2][st.col]; break;
				case oeste: veces = matriz[st.fil+2][st.col-2]; break;
				case noroeste: veces = matriz[st.fil][st.col-2]; break;
			}
	}else if(n == 8) {
			switch(st.brujula) {
				case norte: veces = matriz[st.fil-2][st.col+2]; break;
				case noreste: veces = matriz[st.fil][st.col+2]; break;
				case este: veces = matriz[st.fil+2][st.col+2]; break;
				case sureste: veces = matriz[st.fil+2][st.col]; break;
				case sur: veces = matriz[st.fil+2][st.col-2]; break;
				case suroeste: veces = matriz[st.fil][st.col-2]; break;
				case oeste: veces = matriz[st.fil-2][st.col-2]; break;
				case noroeste: veces = matriz[st.fil-2][st.col]; break;
			}
	
	} else if (n == 3) {
		switch(st.brujula) {
			case norte: veces = matriz[st.fil-1][st.col+1]; break;
			case noreste: veces = matriz[st.fil][st.col+1]; break;
			case este: veces = matriz[st.fil+1][st.col+1]; break;
			case sureste: veces = matriz[st.fil+1][st.col]; break;
			case sur: veces = matriz[st.fil+1][st.col-1]; break;
			case suroeste: veces = matriz[st.fil][st.col-1]; break;
			case oeste: veces = matriz[st.fil-1][st.col-1]; break;
			case noroeste: veces = matriz[st.fil-1][st.col]; break;
		}
	} else if(n == 2) {
		switch(st.brujula) {
			case norte: veces = matriz[st.fil-1][st.col]; break;
			case noreste: veces = matriz[st.fil-1][st.col+1]; break;
			case este: veces = matriz[st.fil][st.col+1]; break;
			case sureste: veces = matriz[st.fil+1][st.col+1]; break;
			case sur: veces = matriz[st.fil+1][st.col]; break;
			case suroeste: veces = matriz[st.fil+1][st.col-1]; break;
			case oeste: veces = matriz[st.fil][st.col-1]; break;
			case noroeste: veces = matriz[st.fil-1][st.col-1]; break;
		}
	}else if(n == 9) {
		switch(st.brujula) {
			case norte: veces = matriz[st.fil-2][st.col-2]; break;
			case noreste: veces = matriz[st.fil-2][st.col]; break;
			case este: veces = matriz[st.fil-3][st.col+3]; break;
			case sureste: veces = matriz[st.fil][st.col+3]; break;
			case sur: veces = matriz[st.fil+2][st.col+2]; break;
			case suroeste: veces = matriz[st.fil+3][st.col]; break;
			case oeste: veces = matriz[st.fil+3][st.col-3]; break;
			case noroeste: veces = matriz[st.fil][st.col-3]; break;
		}
	}else if(n == 15) {
		switch(st.brujula) {
			case norte: veces = matriz[st.fil-3][st.col+3]; break;
			case noreste: veces = matriz[st.fil][st.col+3]; break;
			case este: veces = matriz[st.fil+3][st.col+3]; break;
			case sureste: veces = matriz[st.fil+3][st.col]; break;
			case sur: veces = matriz[st.fil+3][st.col-3]; break;
			case suroeste: veces = matriz[st.fil][st.col-3]; break;
			case oeste: veces = matriz[st.fil-3][st.col-3]; break;
			case noroeste: veces = matriz[st.fil-3][st.col]; break;
		}
	}
	
	return veces;
} 

int comprobarRodeado(char c,state &st, vector < vector <unsigned char> > &matriz) {
	// c puede ser 'A' de agua o 'B' de bosque
	int casillas = 0;
	bool rodeado = true;
	int fila = st.fil;
	int col = st.col;
	for(int i = fila-1; i <= fila+1 ; i++) {
		for(int j = col-1; j <= col+1 ; j++){
			if(matriz[i][j] != c && matriz[i][j] != 'P' && matriz[i][j] != 'M' && (fila != i || col != j)) {
				if(matriz[i][j] != '?') {
					if(matriz[i][j] != 'D' and matriz[i][j]!='K') {
					rodeado = false;
					casillas++;
					}
				}
			}
		}
	}

	return casillas;
}

bool esEsquina(vector < vector <unsigned char> > &matriz,state &st) {
	bool es_esquina = false;
	if(st.brujula == norte) {
		if(matriz[st.fil-1][st.col] == 'M' && matriz[st.fil][st.col-1]=='M'
			or matriz[st.fil-1][st.col] == 'P' && matriz[st.fil][st.col-1]=='P'
			or matriz[st.fil-1][st.col] == 'B' and matriz[st.fil][st.col-1] == 'B' and !st.lleva_zapas
			or matriz[st.fil-1][st.col] == 'A' and matriz[st.fil][st.col-1] == 'A' and !st.lleva_bikini) {
			es_esquina = true;
		} else if(matriz[st.fil-1][st.col] == 'M' && matriz[st.fil][st.col+1]=='M'
			or matriz[st.fil-1][st.col] == 'P' && matriz[st.fil][st.col+1]=='P'
			or matriz[st.fil-1][st.col] == 'B' and matriz[st.fil][st.col+1] == 'B' and !st.lleva_zapas
			or matriz[st.fil-1][st.col] == 'A' and matriz[st.fil][st.col+1] == 'A' and !st.lleva_bikini){
			es_esquina = true;
		}
	} else if(st.brujula == sur) {
		if(matriz[st.fil+1][st.col] == 'M' && matriz[st.fil][st.col-1]=='M'
			or matriz[st.fil+1][st.col] == 'P' && matriz[st.fil][st.col-1]=='P'
			or matriz[st.fil+1][st.col] == 'B' and matriz[st.fil][st.col-1] == 'B' and !st.lleva_zapas
			or matriz[st.fil+1][st.col] == 'A' and matriz[st.fil][st.col-1] == 'A' and !st.lleva_bikini) {
			es_esquina = true;
		} else if(matriz[st.fil+1][st.col] == 'M' && matriz[st.fil][st.col+1]=='M'
			or matriz[st.fil+1][st.col] == 'P' && matriz[st.fil][st.col+1]=='P'
			or matriz[st.fil+1][st.col] == 'B' and matriz[st.fil][st.col+1] == 'B' and !st.lleva_zapas
			or matriz[st.fil+1][st.col] == 'A' and matriz[st.fil][st.col+1] == 'A' and !st.lleva_bikini){
			es_esquina = true;
		}
	} else if(st.brujula == este) {
		if(matriz[st.fil+1][st.col] == 'M' && matriz[st.fil][st.col+1]=='M'
			or matriz[st.fil+1][st.col] == 'P' && matriz[st.fil][st.col+1]=='P'
			or matriz[st.fil+1][st.col] == 'B' and matriz[st.fil][st.col+1] == 'B' and !st.lleva_zapas
			or matriz[st.fil+1][st.col] == 'A' and matriz[st.fil][st.col+1] == 'A' and !st.lleva_bikini) {
			es_esquina = true;
		} else if(matriz[st.fil-1][st.col] == 'M' && matriz[st.fil][st.col+1]=='M'
			or matriz[st.fil-1][st.col] == 'P' && matriz[st.fil][st.col+1]=='P'
			or matriz[st.fil-1][st.col] == 'B' and matriz[st.fil][st.col+1] == 'B' and !st.lleva_zapas
			or matriz[st.fil-1][st.col] == 'A' and matriz[st.fil][st.col+1] == 'A' and !st.lleva_bikini){
			es_esquina = true;
		}
	} else if(st.brujula == oeste) {
		if(matriz[st.fil+1][st.col] == 'M' && matriz[st.fil][st.col-1]=='M'
			or matriz[st.fil+1][st.col] == 'P' && matriz[st.fil][st.col-1]=='P'
			or matriz[st.fil+1][st.col] == 'B' and matriz[st.fil][st.col-1] == 'B' and !st.lleva_zapas
			or matriz[st.fil+1][st.col] == 'A' and matriz[st.fil][st.col-1] == 'A' and !st.lleva_bikini) {
			es_esquina = true;
		} else if(matriz[st.fil-1][st.col] == 'M' && matriz[st.fil][st.col-1]=='M'
			or matriz[st.fil-1][st.col] == 'P' && matriz[st.fil][st.col-1]=='P'
			or matriz[st.fil-1][st.col] == 'B' and matriz[st.fil][st.col-1] == 'B' and !st.lleva_zapas
			or matriz[st.fil-1][st.col] == 'A' and matriz[st.fil][st.col-1] == 'A' and !st.lleva_bikini){
			es_esquina = true;
		}
	} else if(st.brujula == noreste) {
		if(matriz[st.fil][st.col+1]== 'M' && matriz[st.fil-1][st.col]=='M'
			or matriz[st.fil][st.col+1]== 'P' && matriz[st.fil-1][st.col]=='P'
			or matriz[st.fil][st.col+1] == 'B' and matriz[st.fil-1][st.col] == 'B' and !st.lleva_zapas
			or matriz[st.fil][st.col+1] == 'A' and matriz[st.fil-1][st.col] == 'A' and !st.lleva_bikini) {
			es_esquina = true;
		}
	}else if(st.brujula == sureste) {
		if(matriz[st.fil][st.col+1]== 'M' && matriz[st.fil+1][st.col]=='M'
			or matriz[st.fil][st.col+1]== 'P' && matriz[st.fil+1][st.col]=='P'
			or matriz[st.fil][st.col+1] == 'B' and matriz[st.fil+1][st.col] == 'B' and !st.lleva_zapas
			or matriz[st.fil][st.col+1] == 'A' and matriz[st.fil+1][st.col] == 'A' and !st.lleva_bikini) {
			es_esquina = true;
		}
	}else if(st.brujula == suroeste) {
		if(matriz[st.fil][st.col-1]== 'M' && matriz[st.fil+1][st.col]=='M'
			or matriz[st.fil][st.col-1]== 'P' && matriz[st.fil+1][st.col]=='P'
			or matriz[st.fil][st.col-1] == 'B' and matriz[st.fil+1][st.col] == 'B' and !st.lleva_zapas
			or matriz[st.fil][st.col-1] == 'A' and matriz[st.fil+1][st.col] == 'A' and !st.lleva_bikini) {
			es_esquina = true;
		}
	}else if(st.brujula == noroeste) {
		if(matriz[st.fil][st.col-1]== 'M' && matriz[st.fil-1][st.col]=='M'
			or matriz[st.fil][st.col-1]== 'P' && matriz[st.fil-1][st.col]=='P'
			or matriz[st.fil][st.col-1] == 'B' and matriz[st.fil-1][st.col] == 'B' and !st.lleva_zapas
			or matriz[st.fil][st.col-1] == 'A' and matriz[st.fil-1][st.col] == 'A' and !st.lleva_bikini) {
			es_esquina = true;
		}
	}
	return es_esquina;
}

Action girar_norte(const state &st) {
	Action accion;
	switch(st.brujula) {
		case norte: accion = actIDLE; break;
			case noreste: accion = actTURN_SL; break;
			case este: accion = actTURN_SL; break;
			case sureste: accion = actTURN_BL; break;
			case sur: accion = actTURN_BL; break;
			case suroeste: accion = actTURN_BR; break;
			case oeste: accion = actTURN_SR; break;
			case noroeste: accion = actTURN_SR; break;
	}
	return accion;
}
Action girar_sur(const state &st) {
	Action accion;
	switch(st.brujula) {
		case norte: accion = actTURN_BL; break;
			case noreste: accion = actTURN_BR; break;
			case este: accion = actTURN_SR; break;
			case sureste: accion = actTURN_SR; break;
			case sur: accion = actIDLE; break;
			case suroeste: accion = actTURN_SL; break;
			case oeste: accion = actTURN_SL; break;
			case noroeste: accion = actTURN_BL; break;
	}
	return accion;
}

Action girar_este(const state &st) {
	Action accion;
	switch(st.brujula) {
		case norte: accion = actTURN_SR; break;
			case noreste: accion = actTURN_SR; break;
			case este: accion = actIDLE; break;
			case sureste: accion = actTURN_SL; break;
			case sur: accion = actTURN_SL; break;
			case suroeste: accion = actTURN_BL; break;
			case oeste: accion = actTURN_BL; break;
			case noroeste: accion = actTURN_BR; break;
	}
	return accion;
}

Action girar_oeste(const state &st) {
	Action accion;
	switch(st.brujula) {
		case norte: accion = actTURN_SL; break;
			case noreste: accion = actTURN_BL; break;
			case este: accion = actTURN_BL; break;
			case sureste: accion = actTURN_BR; break;
			case sur: accion = actTURN_SR; break;
			case suroeste: accion = actTURN_SR; break;
			case oeste: accion = actIDLE; break;
			case noroeste: accion = actTURN_SL; break;
	}
	return accion;
}

bool comprobarMuro(vector < vector <unsigned char> > &matriz, const state &st){
	bool hay_muro = false;
	if((matriz[st.fil-1][st.col] == 'M' && matriz[st.fil+1][st.col] == 'M') || (matriz[st.fil-1][st.col] == 'P' && matriz[st.fil+1][st.col] == 'P')
	or (matriz[st.fil-1][st.col] == 'B' && matriz[st.fil+1][st.col] == 'B' and !st.lleva_zapas) or (matriz[st.fil-1][st.col] == 'A' && matriz[st.fil+1][st.col] == 'A' and !st.lleva_bikini)) {
		hay_muro = true;
	} else if((matriz[st.fil-1][st.col] == 'M' && matriz[st.fil+1][st.col] == 'M') or (matriz[st.fil][st.col-1] == 'P' && matriz[st.fil][st.col+1] == 'P')
	or(matriz[st.fil-1][st.col] == 'B' && matriz[st.fil+1][st.col] == 'B' and !st.lleva_zapas) or (matriz[st.fil-1][st.col] == 'A' && matriz[st.fil+1][st.col] == 'A' and !st.lleva_bikini)){
		hay_muro = true;
	}
	return hay_muro;
}

int se_ve_recarga(Sensores sensores) {
	int se_ve = -1;
	for(int i = 0; i < 15 && se_ve==-1; i++) {
		if(sensores.terreno[i] == 'X') {
			se_ve = i;
		}
	}
	return se_ve;
}

int se_ven_zapas(Sensores sensores) {
	int se_ve = -1;
	for(int i = 0; i < 15 && se_ve==-1; i++) {
		if(sensores.terreno[i]=='D'){
			se_ve = i;
		}
	}
	return se_ve;
}

int se_ve_bikini(Sensores sensores) {
	int se_ve = -1;
	for(int i = 0; i < 15 && se_ve==-1; i++) {
		if(sensores.terreno[i]=='K'){
			se_ve = i;
		}
	}
	return se_ve;
}

void pasarMatriz(Sensores s, int* fila, int *col, const state &st, int casilla) {
	int pos = 1;
	if(st.brujula == norte) {
		switch(casilla) {
			case 1: *fila = st.fil-1; *col = st.col-1; break;
			case 2:*fila = st.fil-1; *col =st.col; break;
			case 3: *fila= st.fil-1; *col = st.col+1; break;
			case 4: *fila = st.fil-2; *col = st.col-2; break;
			case 5: *fila = st.fil-2; *col = st.col-1; break;
			case 6: *fila = st.fil-2; *col = st.col; break;
			case 7:*fila = st.fil-2; *col = st.col+1; break;
			case 8: *fila = st.fil-2; *col = st.col+2; break;
			case 9: *fila = st.fil-3; *col = st.col-3; break;
			case 10:*fila = st.fil-3; *col = st.col-2; break;
			case 11:*fila = st.fil-3; *col = st.col-1; break;
			case 12:*fila = st.fil-3; *col = st.col; break;
			case 13:*fila = st.fil-3; *col = st.col+1; break;
			case 14: *fila = st.fil-3; *col = st.col+2; break;
			case 15:*fila = st.fil-3; *col = st.col+3; break;
		}
	} else if(st.brujula == sur) {
		for(int fil = 1; fil <= 3; fil++) {
			for(int columna = fil; columna >= -fil; columna--) {
				if(casilla == pos) {
					*fila = st.fil +fil;
					*col = st.col +columna;
				} else {
					pos++;
				}
			}
		}
	} else if(st.brujula == este) {
		for(int columna = 1; columna <= 3; columna++) {
			for(int fil = -columna; fil <= columna; fil++) {
				if(casilla == pos) {
					*fila = st.fil +fil;
					*col = st.col +columna;
				} else {
					pos++;
				}
			}
		}
	} else if(st.brujula == oeste) {
		for(int columna = -1; columna >= -3; columna--) {
			for(int fil = -columna; fil >= columna; fil--) {
				if(casilla == pos) {
					*fila = st.fil +fil;
					*col = st.col +columna;
				} else {
					pos++;
				}
			}
		}
	}
}


Action accion_recarga(Sensores sensores,char c) {
	Action accion = actIDLE;
	int pos;
	if(c == 'D'){
		pos = se_ven_zapas(sensores);
	} else if (c == 'R'){
		pos = se_ve_recarga(sensores);
	}else if(c == 'G'){
		pos = se_ve_posicionamiento(sensores);
	} else if(c == 'K') {
		pos = se_ve_bikini(sensores);
	}
	switch(pos) {
		case 1: accion = actTURN_SL; break;
		case 4: accion = actTURN_SL; break;
		case 5: accion = actTURN_SL; break;
		case 9: accion = actTURN_SL; break;
		case 10: accion = actTURN_SL; break;
		case 11: accion = actTURN_SL; break;
	}
	switch(pos) {
		case 3:accion = actTURN_SR; break;
		case 7:accion = actTURN_SR; break;
		case 8:accion = actTURN_SR; break;
		case 13:accion = actTURN_SR; break;
		case 14: accion = actTURN_SR; break;
		case 15: accion = actTURN_SR; break;
	}
	switch(pos) {
		case 2:accion = actFORWARD; break;
		case 6: accion = actFORWARD; break;
		case 12: accion = actFORWARD; break;
	}

	return accion;
}

void rellenarMapaProv(vector<vector<unsigned char>> &mapa,Action accion, Orientacion *ori, int *fila, int *col,Sensores sensores) {
	state aux;
	aux.brujula = (Orientacion) *ori;
	aux.fil = *fila;
	aux.col = *col;
	aux.lleva_bikini = false;
	aux.lleva_zapas = false;
	PonerTerrenoEnMatriz(sensores.terreno, aux,mapa);

	if(accion == actTURN_SL) {
		*ori = static_cast<Orientacion> ((*ori-1+8)%8);
	} else if(accion == actTURN_SR) {
		*ori = static_cast<Orientacion>((*ori+1+8)%8);
	} else if(accion == actTURN_BL) {
		*ori = static_cast<Orientacion>((*ori-3+8)%8);
	} else if(accion == actTURN_BR) {
		*ori =static_cast<Orientacion> ((*ori+3+8)%8);
	} else if(accion == actFORWARD) {
		switch(*ori) {
			case 0: (*fila)--; break;
			case 1: (*fila)--; (*col)++; break;
			case 2: (*col)++; break;
			case 3: (*fila)++; (*col)++; break;
			case 4: (*fila)++; break;
			case 5: (*fila)++; (*col)--; break;
			case 6: (*col)--; break;
			case 7: (*fila)--; (*col)--; break;
		}
	}
}

int pegadoMuro(vector<vector<unsigned char>> &mapa, Orientacion o, int fila, int col, bool zapas,bool bik) {
	int lado = -1;
	if(fila-1 <= 0 || fila +1 >= mapa.size() -2 || col-1 <= 0 || col+1 >= mapa.size()-2) {
		return -1;
	}
	if(o == norte) {
		if(mapa[fila][col-1] == 'M' or mapa[fila][col-1] == 'P') lado = 0; //hace sl
		else if((mapa[fila][col-1] == 'B' and !zapas) or (mapa[fila][col-1] == 'A' and !bik)) lado = 0;
		else if(mapa[fila][col+1] == 'M' or mapa[fila][col+1] == 'P') lado = 1; // hace sr
		else if((mapa[fila][col+1] == 'B' and !zapas) or (mapa[fila][col+1] == 'A' and !bik)) lado = 1;
	} else if(o == noreste) {
		if(mapa[fila-1][col-1] == 'M' or mapa[fila-1][col-1] == 'P') lado = 0;
		else if((mapa[fila-1][col-1] == 'B' and !zapas) or (mapa[fila-1][col-1] == 'A' and !bik)) lado = 0;
		else if(mapa[fila+1][col+1] == 'M' or mapa[fila+1][col+1] == 'P') lado = 1;
		else if((mapa[fila+1][col+1] == 'B' and !zapas) or (mapa[fila+1][col+1] == 'A' and !bik)) lado = 1;
	} else if( o == este) {
		if(mapa[fila-1][col] == 'M' or mapa[fila-1][col] == 'P') lado = 0;
		else if((mapa[fila-1][col] == 'B' and !zapas) or (mapa[fila-1][col] == 'A' and !bik)) lado = 0;
		else if(mapa[fila+1][col] == 'M' or mapa[fila+1][col] == 'P') lado = 1;
		else if((mapa[fila+1][col] == 'B' and !zapas) or (mapa[fila+1][col] == 'A' and !bik)) lado = 1;
	} else if(o == sureste) {
		if(mapa[fila-1][col+1] == 'M' or mapa[fila-1][col+1] == 'P') lado = 0;
		else if((mapa[fila-1][col+1] == 'B' and !zapas) or (mapa[fila-1][col+1] == 'A' and !bik)) lado = 0;
		else if(mapa[fila+1][col-1] == 'M' or mapa[fila+1][col-1] == 'P' ) lado = 1;
		else if((mapa[fila+1][col-1] == 'B' and !zapas) or (mapa[fila+1][col-1] == 'A' and !bik)) lado = 1;
	} else if(o == sur) {
		if(mapa[fila][col+1] == 'M' or mapa[fila][col+1] == 'P') lado = 0;
		else if((mapa[fila][col+1] == 'B' and !zapas) or (mapa[fila][col+1] == 'A' and !bik)) lado = 0;
		else if(mapa[fila][col-1] == 'M' or mapa[fila][col-1] == 'P') lado = 1;
		else if((mapa[fila][col-1] == 'B' and !zapas) or (mapa[fila][col-1] == 'A' and !bik)) lado = 1;
	} else if(o == suroeste) {
		if(mapa[fila+1][col+1] == 'M' or mapa[fila+1][col+1] == 'P') lado = 0;
		else if((mapa[fila+1][col+1] == 'B' and !zapas) or (mapa[fila+1][col+1] == 'A' and !bik)) lado = 0;
		else if(mapa[fila-1][col-1] == 'M' or mapa[fila-1][col-1] == 'P') lado = 1;
		else if((mapa[fila-1][col-1] == 'B' and !zapas) or (mapa[fila-1][col-1] == 'A' and !bik)) lado = 1;
	} else if(o == oeste) {
		if(mapa[fila+1][col] == 'M' or mapa[fila+1][col] == 'P') lado = 0;
		else if((mapa[fila+1][col] == 'B' and !zapas) or (mapa[fila+1][col] == 'A' and !bik)) lado = 0;
		else if(mapa[fila-1][col] == 'M' or mapa[fila-1][col] == 'P') lado = 1;
		else if((mapa[fila-1][col] == 'B' and !zapas) or (mapa[fila-1][col] == 'A' and !bik)) lado = 1;
	} else if(o == noroeste) {
		if(mapa[fila+1][col-1] == 'M' or mapa[fila+1][col-1] == 'P') lado = 0;
		else if((mapa[fila+1][col-1] == 'B' and !zapas) or (mapa[fila+1][col-1] == 'A' and !bik)) lado = 0;
		else if(mapa[fila-1][col+1]== 'M' or mapa[fila-1][col+1]== 'P') lado = 1;
		else if((mapa[fila-1][col+1] == 'B' and !zapas) or (mapa[fila-1][col+1] == 'A' and !bik)) lado = 1;
	}
	return lado;
}

Action ComportamientoJugador::think(Sensores sensores){

	Action accion = actIDLE;

	cout << "Posicion: fila " << sensores.posF << " columna " << sensores.posC << " ";
	switch(sensores.sentido){
		case 0: cout << "Norte" << endl; break;
		case 1: cout << "Noreste" << endl; break;
		case 2: cout << "Este" << endl; break;
		case 3: cout << "Sureste" << endl; break;
		case 4: cout << "Sur" << endl; break;
		case 5: cout << "Suroeste" << endl; break;
		case 6: cout << "Oeste" << endl; break;
		case 7: cout << "Noroeste" << endl; break;
	}
	cout << "Terreno: ";
	for (int i=0; i<sensores.terreno.size(); i++)
		cout << sensores.terreno[i];
	cout << endl;

	cout << "Superficie: ";
	for (int i=0; i<sensores.superficie.size(); i++)
		cout << sensores.superficie[i];
	cout << endl;

	cout << "Colisión: " << sensores.colision << endl;
	cout << "Reset: " << sensores.reset << endl;
	cout << "Vida: " << sensores.vida << endl;
	cout << endl;


	// Determinar el efecto de la ultima accion enviada
	switch(last_action) {
		case actFORWARD:
			switch (current_state.brujula){
				case norte: current_state.fil--; break;
				case noreste: current_state.fil--; current_state.col++; break;
				case este: current_state.col++; break;
				case sureste: current_state.fil++; current_state.col++; break;
				case sur: current_state.fil++; break;
				case suroeste: current_state.fil++; current_state.col--; break;
				case oeste: current_state.col--; break;
				case noroeste: current_state.fil--; current_state.col--; break;
			}
			break;
		case actTURN_SL:
			current_state.brujula = static_cast<Orientacion>((current_state.brujula+7)%8);
			break;
		case actTURN_SR:
			current_state.brujula = static_cast<Orientacion>((current_state.brujula+1)%8);
			break;
		case actTURN_BL:
			current_state.brujula = static_cast<Orientacion>((current_state.brujula+5)%8);
			break;
		case actTURN_BR:
			current_state.brujula = static_cast<Orientacion>((current_state.brujula+3)%8);
			break;
	}

	if(sensores.reset == true) {
		bien_situado = false;
		current_state.lleva_bikini = false;
		stProv.lleva_bikini = false;
		current_state.lleva_zapas = false;
		stProv.lleva_zapas = false;
		current_state.brujula = norte;
		stProv.brujula = norte;
		stProv.fil = mapaResultado.size();
		stProv.col = mapaResultado.size();

		for(int i = 0; i < mapaResultado.size()*2; i++) {
			for(int j = 0; j < mapaResultado.size()*2;j++) {
				mapaProv[i][j] = '?';
			}
		}
		empiezaEnMuro = false;
      	busca_salida = false;
	}

	// Decidir nueva acción
	if((sensores.posF != -1 and !bien_situado and sensores.nivel==0) or (sensores.terreno[0]=='G' and !bien_situado and sensores.nivel > 0)) {
		// cout << "entro  " << endl; 
		current_state.fil = sensores.posF;
		current_state.col = sensores.posC;
		current_state.brujula = sensores.sentido;
		bien_situado = true;

		cout << "Sensores fila: " << sensores.posF << endl;
		cout << "Sensores columna: " << sensores.posC << endl;

		if(sensores.terreno[0] == 'G') {
			trasladarMatrizMR(mapaProv,mapaResultado,stProv,current_state);
			trasladarMatrizVP(vecesPosicionadoProv, vecesPosicionado,stProv,current_state);
		}


	} else if(!bien_situado) {
		current_state.brujula = stProv.brujula;
		if(sensores.terreno[0] == 'K') {
			current_state.lleva_bikini = true;
			stProv.lleva_bikini = true;
		} else if(sensores.terreno[0] == 'D') {
			current_state.lleva_zapas = true;
			stProv.lleva_zapas = true;
		}
	}

	if(bien_situado) {
		// cout << "Last action: " <<  last_action;
		// cout << "Fila: " << current_state.fil << " Columna: " << current_state.col << endl;
		//mapaResultado[current_state.fil][current_state.col] = sensores.terreno[0];
		PonerTerrenoEnMatriz(sensores.terreno, current_state, mapaResultado);
		rellenarPrecipicios(mapaResultado);
		buscando_pos = false;
	}

	if(sensores.terreno[0] == 'K') {
		current_state.lleva_bikini = true;
		stProv.lleva_bikini = true;
		buscando_bikini = false;
	} else if(sensores.terreno[0] == 'D') {
		current_state.lleva_zapas = true;
		stProv.lleva_zapas = true;
		buscando_zapas = false;
	}

	int recarga = se_ve_recarga(sensores);

	if(sensores.bateria <= 1000 && sensores.vida>=300 && !busca_recarga && !filas_recarga.empty()) {
		int d_f,d_c;
		if(sensores.posF > filas_recarga.at(0)){
            d_f = sensores.posF - filas_recarga.at(0);
		} else {
			d_f = -sensores.posF + filas_recarga.at(0);
		}

		if(sensores.posC > cols_recarga.at(0)){
            d_c = sensores.posC - cols_recarga.at(0);
		} else {
			d_c = -sensores.posC + cols_recarga.at(0);
		}
		double dis_menor = d_f + d_c;
		for(int i = 1; i < filas_recarga.size(); i++) {
            if(sensores.posF > filas_recarga.at(i)){
				d_f = sensores.posF - filas_recarga.at(i);
			} else {
				d_f = -sensores.posF + filas_recarga.at(i);
			}

			if(sensores.posC > cols_recarga.at(i)){
				d_c = sensores.posC - cols_recarga.at(i);
			} else {
				d_c = -sensores.posC + cols_recarga.at(i);
			}
			if(d_f + d_c< dis_menor) {
				dis_menor = d_f + d_c;
				recarga_cercana = i;
			}
		}

		if(sensores.vida >= dis_menor) {
			busca_recarga = true;
		}
	}

	if(buscando_pos || (se_ve_posicionamiento(sensores)!= -1 && !bien_situado)){
		buscando_pos = true;
		if(ha_andado) {
			accion = accion_recarga(sensores,'G');
			ha_andado = false;
		} else {
			if((sensores.terreno[2]=='T' or sensores.terreno[2]=='S'
			or sensores.terreno[2]== 'G'  or sensores.terreno[2]=='D' or sensores.terreno[2]=='K')
			and sensores.superficie[2]=='_') {
				accion = actFORWARD;
				ha_andado = true;
			} else {
				buscando_pos = false;
			}
			
		}
		if(accion == actIDLE ) {
			buscando_pos = false;
			ha_andado = false;
			//aniadir_recarga(current_state.fil, current_state.col, filas_recarga, cols_recarga);
		}

	} else if(se_ve_posicionamiento(sensores) == -1) {
		buscando_pos = false;
	}

	if((recarga>0 && bien_situado)  && (pasos_sin_recargar > 2000 || busca_recarga) && !sigue_recargando) {
		busca_recarga = false;
		if(ha_andado) {
			accion = accion_recarga(sensores,'R');
			if(accion != actFORWARD)
				ha_andado = false;
		} else {
			accion = actFORWARD;
			ha_andado = true;
		}
		
		if(accion == actIDLE ) {
			pasos_sin_recargar = 0;
			ha_andado = false;
			sigue_recargando = true;
		}
	}else if(bien_situado && busca_recarga && !hay_obstaculo){
		cout << "Fila recarga: " <<  filas_recarga[recarga_cercana] << endl;
		cout << "Col recarga: " << cols_recarga[recarga_cercana] << endl;
		if(busca_recarga) {
			if((ha_andado || sin_diagonal(current_state.brujula)) && !hay_obstaculo) {
				if(filas_recarga[recarga_cercana] > current_state.fil) {
					accion = girar_sur(current_state);
				} else if(filas_recarga[recarga_cercana] < current_state.fil) {
					accion = girar_norte(current_state);
				} else if(cols_recarga[recarga_cercana] > current_state.col) {
					accion = girar_este(current_state);
				} else if (cols_recarga[recarga_cercana] < current_state.col) {
					accion = girar_oeste(current_state);
				} else {
					busca_recarga = false;
				}
				ha_andado = false;
				if(accion == actIDLE and terrenoAccesible(sensores,2,current_state)) {
					accion = actFORWARD;
				} else if(!terrenoAccesible(sensores,2,current_state)){
					hay_obstaculo = true;
				}
			} else if(!hay_obstaculo){
				if(terrenoAccesible(sensores,2,current_state)) {
					accion = actFORWARD;
					ha_andado = true;
				} else {
					hay_obstaculo = true;
				}
			} else {
				if(terrenoAccesible(sensores,2,current_state)) {
					accion = actFORWARD;
					ha_andado = true;
					hay_obstaculo = false;
				}
			}
		}
	}else if(bien_situado && hay_obstaculo){
		if(terrenoAccesible(sensores,1,current_state)) {
			accion = actTURN_SL;
		} else if(terrenoAccesible(sensores,3,current_state)){
			accion = actTURN_SR;
		} else {
			if(se_ve_bikini(sensores) == -1 and se_ve_recarga(sensores) == -1 and se_ven_zapas(sensores)==-1) {
				hay_obstaculo = false;
				buscando_zapas = false;
				buscando_bikini = false;
			} else {
				accion = actTURN_BL;
			}
		}
		hay_obstaculo = false;
	}else if(recarga>0 && bien_situado){
		int f = sacar_filas_recarga(recarga,current_state) + current_state.fil;
		int c = sacar_cols_recarga(recarga,current_state) + current_state.col;
		bool aniadir = true;
		for(int i = 0; i < filas_recarga.size() && aniadir; i++) {
			if(filas_recarga.at(i) == f && cols_recarga.at(i) == c) {
                aniadir = false;
			}
		}
        if(aniadir) {
			filas_recarga.push_back(f);
			cols_recarga.push_back(c);
		}

	} else if(buscando_zapas || (se_ven_zapas(sensores)!= -1 && bien_situado) && !current_state.lleva_zapas && !sigue_recargando){
		buscando_zapas = true;
		if(ha_andado) {
			accion = accion_recarga(sensores,'D');
			ha_andado = false;
		} else {
			if((sensores.terreno[2]=='T' or sensores.terreno[2]=='S'
			or sensores.terreno[2]== 'G'  or sensores.terreno[2]=='D' or sensores.terreno[2]=='K' or sensores.terreno[2] == 'B')
			and sensores.superficie[2]=='_') {
				accion = actFORWARD;
				ha_andado = true;
			} else {
				buscando_zapas = false;
			}
			
		}
		cout << accion << endl;
		if(accion == actIDLE ) {
			buscando_zapas = false;
			ha_andado = false;
			//aniadir_recarga(current_state.fil, current_state.col, filas_recarga, cols_recarga);
		}
	}else if(buscando_bikini || (se_ve_bikini(sensores)!= -1 && bien_situado) && !current_state.lleva_bikini && !sigue_recargando){
		buscando_bikini = true;
		if(ha_andado) {
			accion = accion_recarga(sensores,'K');
			ha_andado = false;
		} else {
			if((sensores.terreno[2]=='T' or sensores.terreno[2]=='S'
			or sensores.terreno[2]== 'G'  or sensores.terreno[2]=='D' or sensores.terreno[2]=='K' or sensores.terreno[2] == 'A')
			and sensores.superficie[2]=='_') {
				accion = actFORWARD;
				ha_andado = true;
			} else {
				buscando_bikini = false;
			}
			
		}
		if(accion == actIDLE ) {
			buscando_bikini = false;
			ha_andado = false;
			//aniadir_recarga(current_state.fil, current_state.col, filas_recarga, cols_recarga);
		}

	} 
	
	if(se_ve_bikini(sensores) == -1) {
		buscando_bikini = false;
	}
	if(se_ven_zapas(sensores) == -1) {
		buscando_zapas = false;
	}

	if(sigue_recargando || recarga == 0){
		//cout << "Estoy dentro" << endl;
		if((sensores.bateria >= 3*sensores.vida || sensores.bateria >= 3500) or sensores.bateria>=5000){
			sigue_recargando = false;
			busca_recarga = false;
			pasos_sin_recargar = 0;
			ha_andado = false;
		} else {
			accion = actIDLE;
		}
	}

	if(empieza_rodeado  and (comprobarRodeado('B',stProv,mapaProv)==8 and comprobarRodeado('A',stProv,mapaProv) == 8)) {
		empieza_rodeado = false;
	}

	veces_comprobado++;
	// comprobarRodeado me dice el número de casillas que NO SON BOSQUE
	if(bien_situado && (comprobarRodeado('B',current_state, mapaResultado) == 0 ||  (comprobarRodeado('B',current_state, mapaResultado) <= 2 && empieza_rodeado))&& !current_state.lleva_zapas) {
		if((sensores.terreno[2]=='T' or sensores.terreno[2]=='S' or sensores.terreno[2]=='X'
			or sensores.terreno[2]== 'G'  or sensores.terreno[2]=='D'  or sensores.terreno[2]=='K' or sensores.terreno[2] == 'B')
			and sensores.superficie[2]=='_'){
				accion = actFORWARD;
		} else {
			accion = actTURN_BR;
		}

		if(veces_comprobado  == 1) {
			empieza_rodeado = true;
		}
		
		rodeado = true;
	} else if(bien_situado && (comprobarRodeado('A',current_state, mapaResultado) == 0 ||  (comprobarRodeado('A',current_state, mapaResultado) <= 2 && empieza_rodeado)) && !current_state.lleva_bikini) {
		if((sensores.terreno[2]=='T' or sensores.terreno[2]=='S' or sensores.terreno[2]=='X'
			or sensores.terreno[2]== 'G'  or sensores.terreno[2]=='D'  or sensores.terreno[2]=='K' or sensores.terreno[2] == 'A')
			and sensores.superficie[2]=='_'){
				accion = actFORWARD;
		} else {
			accion = actTURN_BR;
		}
		if(veces_comprobado  == 1) {
			empieza_rodeado = true;
		}
		rodeado = true;
	} else if(!buscando_pos &&!bien_situado && (comprobarRodeado('B',stProv, mapaProv) == 0 ||  (comprobarRodeado('B',stProv, mapaProv) <= 2 && empieza_rodeado)) && !stProv.lleva_zapas) {
		if((sensores.terreno[2]=='T' or sensores.terreno[2]=='S' or sensores.terreno[2]=='X'
			or sensores.terreno[2]== 'G'  or sensores.terreno[2]=='D'  or sensores.terreno[2]=='K' or sensores.terreno[2]=='B')
			and sensores.superficie[2]=='_'){
				accion = actFORWARD;
		} else {
			accion = actTURN_BR;
		}
		if(veces_comprobado  == 1) {
			empieza_rodeado = true;
		}
		rodeado = true;
	} else if(!buscando_pos && !bien_situado && (comprobarRodeado('A',stProv, mapaProv) == 0 ||  (comprobarRodeado('A',stProv, mapaProv) <= 2 && empieza_rodeado)) && !stProv.lleva_bikini) {
		if((sensores.terreno[2]=='T' or sensores.terreno[2]=='S' or sensores.terreno[2]=='X'
			or sensores.terreno[2]== 'G'  or sensores.terreno[2]=='D'  or sensores.terreno[2]=='K' or sensores.terreno[2] == 'A')
			and sensores.superficie[2]=='_'){
				accion = actFORWARD;
		} else {
			accion = actTURN_BR;
		}
		if(veces_comprobado  == 1) {
			empieza_rodeado = true;
		}
		rodeado = true;
	}

	if( ( !buscando_zapas && !buscando_bikini && !sigue_recargando && !rodeado && !busca_recarga)  && bien_situado) { // ponía || !bien_situado
		pasos_sin_recargar++;
		if((terrenoAccesible(sensores,2,current_state) /*&& bien_situado */)){
				//cout << "Veces en norte: " << vecesPosicionadoEn(2,vecesPosicionado,current_state) <<  endl;
				//cout << "Veces en derecha: " << vecesPosicionadoEn(3,vecesPosicionado,current_state) <<  endl;
				//cout << "Veces en izquierda: " << vecesPosicionadoEn(1,vecesPosicionado,current_state) <<  endl;
				if(vecesPosicionadoEn(2,vecesPosicionado,current_state) == 0 || numero_giros > 6) {
					accion = actFORWARD;
					//actualizarVecesPosicionado(vecesPosicionado,current_state,sensores);
					ha_girado = false;
					girado_izquierda = false;
      				girado_derecha = false;
					numero_giros = 0;
				} else if (vecesPosicionadoEn(1,vecesPosicionado,current_state) < vecesPosicionadoEn(2,vecesPosicionado,current_state) && !girado_derecha){
					accion = actTURN_SL;
					girado_izquierda = true;
					girado_derecha = false;
					numero_giros++;
				} else if (vecesPosicionadoEn(3,vecesPosicionado,current_state) < vecesPosicionadoEn(2,vecesPosicionado,current_state) && !girado_izquierda){  
					accion = actTURN_SR;
					girado_izquierda = false;
					girado_derecha = true;
					numero_giros++;

				} else if(vecesPosicionadoEn(4,vecesPosicionado,current_state) < vecesPosicionadoEn(8,vecesPosicionado,current_state) && !girado_derecha) {
						accion = actTURN_SL;
						girado_izquierda = true;
						girado_derecha = false;
						numero_giros++;
					} else if(vecesPosicionadoEn(8,vecesPosicionado,current_state) < vecesPosicionadoEn(4,vecesPosicionado,current_state) && !girado_izquierda ) {
						accion = actTURN_SR;
						girado_izquierda = false;
						girado_derecha = true;
						numero_giros++;
					}else if(vecesPosicionadoEn(9,vecesPosicionado,current_state) < vecesPosicionadoEn(15,vecesPosicionado,current_state) && !girado_derecha){
						accion = actTURN_SL;
						girado_izquierda = true;
						girado_derecha = false;
						numero_giros++;
					}else if(vecesPosicionadoEn(9,vecesPosicionado,current_state) > vecesPosicionadoEn(15,vecesPosicionado,current_state) && !girado_izquierda){
						accion = actTURN_SR;
						girado_izquierda = false;
						girado_derecha = true;
						numero_giros++;
					} else if(ha_girado){
						accion = actFORWARD;
						//actualizarVecesPosicionado(vecesPosicionado,current_state,sensores);
						ha_girado = false;
						girado_izquierda = false;
      					girado_derecha = false;
						numero_giros = 0;
					} else {
						if(terrenoAccesible(sensores,12,current_state)) {
							accion = actFORWARD;
							//actualizarVecesPosicionado(vecesPosicionado,current_state,sensores);
							ha_girado = false;
							girado_izquierda = false;
      						girado_derecha = false;
							numero_giros = 0;
						}else {
							//cout << "Veces en norte: " << vecesPosicionadoEn(2,vecesPosicionado,current_state) <<  endl;
							//cout << "Veces en derecha: " << vecesPosicionadoEn(3,vecesPosicionado,current_state) <<  endl;
							//cout << "Veces en izquierda: " << vecesPosicionadoEn(1,vecesPosicionado,current_state) <<  endl;
							accion = actTURN_BL;
							ha_girado = true;
							numero_giros++;
						}
					}
		} else if(terrenoAccesible(sensores,1,current_state) && !ha_girado) {
			accion = actTURN_SL;
			ha_girado = true;
			numero_giros++;
		} else if(terrenoAccesible(sensores,3,current_state) && !ha_girado) {
			accion = actTURN_SR;
			ha_girado = true;
			numero_giros++;
		}
		else if(!girar_derecha){
			accion = actTURN_BL;
			girar_derecha = (rand()%2 == 0);
			ha_girado = false;
			numero_giros++;
		}
		else{
			accion = actTURN_BR;
			girar_derecha = (rand()%2 == 0);
			ha_girado = false;
			numero_giros++;
		}
		
		int pegado = pegadoMuro(mapaResultado,current_state.brujula, current_state.fil,current_state.col,current_state.lleva_zapas, current_state.lleva_bikini);
		bool es_esquina = esEsquina(mapaResultado,current_state);
		if(!comprobarMuro(mapaResultado,current_state) && vecesPosicionadoEn(2,vecesPosicionado,current_state) < 2){
			if((pegado == 1 || pegado == 0) && antes_pegado != 2 and antes_pegado != 3 and terrenoAccesible(sensores,2,current_state)) {
				accion = actFORWARD;
				antes_pegado = pegado;
			} else if((antes_pegado == 0 && !es_esquina) || (antes_pegado==1 && es_esquina)) {
				accion = actTURN_SL;
				if(antes_pegado == 0 && !es_esquina) {
					avanza = true;
				}
				antes_pegado = 2;
			}else if((antes_pegado == 1 and !es_esquina) || (antes_pegado == 0 && es_esquina)) {
				accion = actTURN_SR;
				if(antes_pegado == 1 and !es_esquina) {
					avanza = true;
				}
				antes_pegado = 3;
			} else if(antes_pegado == 2) {
				accion = actTURN_SL;
				antes_pegado = -1;
			} else if(antes_pegado == 3) {
				accion = actTURN_SR;
				antes_pegado = -1;
			} else if(avanza && terrenoAccesible(sensores,2,current_state)){
				accion = actFORWARD;
				antes_pegado = pegado;
				avanza = false;
			} else {
				antes_pegado = pegado;
				avanza = false;
			}
		}

		
	} else if(!bien_situado && !rodeado && !buscando_pos) {
		if((terrenoAccesible(sensores,2,stProv))){
				//cout << "Veces en norte: " << vecesPosicionadoEn(2,vecesPosicionado,current_state) <<  endl;
				//cout << "Veces en derecha: " << vecesPosicionadoEn(3,vecesPosicionado,current_state) <<  endl;
				//cout << "Veces en izquierda: " << vecesPosicionadoEn(1,vecesPosicionado,current_state) <<  endl;
				if(vecesPosicionadoEn(2,vecesPosicionadoProv,stProv) == 0 || numero_giros > 6) {
					accion = actFORWARD;
					//actualizarVecesPosicionado(vecesPosicionadoProv,stProv,sensores);
					ha_girado = false;
					girado_izquierda = false;
      				girado_derecha = false;
					numero_giros = 0;
				} else if (vecesPosicionadoEn(1,vecesPosicionadoProv,stProv) < vecesPosicionadoEn(2,vecesPosicionadoProv,stProv) && !girado_derecha){
					accion = actTURN_SL;
					girado_izquierda = true;
					girado_derecha = false;
					numero_giros++;
				} else if (vecesPosicionadoEn(3,vecesPosicionadoProv,stProv) < vecesPosicionadoEn(2,vecesPosicionadoProv,stProv) && !girado_izquierda){  
					accion = actTURN_SR;
					girado_izquierda = false;
					girado_derecha = true;
					numero_giros++;

				} else if(vecesPosicionadoEn(4,vecesPosicionadoProv,stProv) < vecesPosicionadoEn(8,vecesPosicionadoProv,stProv) && !girado_derecha) {
						accion = actTURN_SL;
						girado_izquierda = true;
						girado_derecha = false;
						numero_giros++;
					} else if(vecesPosicionadoEn(8,vecesPosicionadoProv,stProv) < vecesPosicionadoEn(4,vecesPosicionadoProv,stProv) && !girado_izquierda ) {
						accion = actTURN_SR;
						girado_izquierda = false;
						girado_derecha = true;
						numero_giros++;
					}else if(vecesPosicionadoEn(9,vecesPosicionadoProv,stProv) < vecesPosicionadoEn(15,vecesPosicionadoProv,stProv) && !girado_derecha){
						accion = actTURN_SL;
						girado_izquierda = true;
						girado_derecha = false;
						numero_giros++;
					}else if(vecesPosicionadoEn(9,vecesPosicionadoProv,stProv) > vecesPosicionadoEn(15,vecesPosicionadoProv,stProv) && !girado_izquierda){
						accion = actTURN_SR;
						girado_izquierda = false;
						girado_derecha = true;
						numero_giros++;
					} else if(ha_girado){
						accion = actFORWARD;
						//actualizarVecesPosicionado(vecesPosicionadoProv,stProv,sensores);
						ha_girado = false;
						girado_izquierda = false;
      					girado_derecha = false;
						numero_giros = 0;
					} else {
						if(terrenoAccesible(sensores,12,current_state)) {
							accion = actFORWARD;
							//actualizarVecesPosicionado(vecesPosicionadoProv,stProv,sensores);
							ha_girado = false;
							girado_izquierda = false;
      						girado_derecha = false;
							numero_giros = 0;
						}else {
							//cout << "Veces en norte: " << vecesPosicionadoEn(2,vecesPosicionadoProv,stProv) <<  endl;
							//cout << "Veces en derecha: " << vecesPosicionadoEn(3,vecesPosicionadoProv,stProv) <<  endl;
							//cout << "Veces en izquierda: " << vecesPosicionadoEn(1,vecesPosicionadoProv,stProv) <<  endl;
							accion = actTURN_BL;
							ha_girado = true;
							numero_giros++;
						}
					}
		} else if(terrenoAccesible(sensores,1,stProv) && !ha_girado) {
			accion = actTURN_SL;
			ha_girado = true;
			numero_giros++;
		} else if(terrenoAccesible(sensores,3,stProv) && !ha_girado) {
			accion = actTURN_SR;
			ha_girado = true;
			numero_giros++;
		}
		else if(!girar_derecha){
			accion = actTURN_BL;
			girar_derecha = (rand()%2 == 0);
			ha_girado = false;
			numero_giros++;
		}
		else{
			accion = actTURN_BR;
			girar_derecha = (rand()%2 == 0);
			ha_girado = false;
			numero_giros++;
		}
	}

	if(bien_situado && accion == actFORWARD) {
		actualizarVecesPosicionado(vecesPosicionado,current_state,sensores);
	} else if(!bien_situado && accion == actFORWARD) {
		actualizarVecesPosicionado(vecesPosicionadoProv,stProv,sensores);
	}

	if(sensores.nivel > 0) {
		rellenarMapaProv(mapaProv,accion,&stProv.brujula, &stProv.fil,&stProv.col, sensores);
		//cout << "Orientación: " << stProv.brujula << endl;
		//cout << "Fila: " << stProv.fil << endl;
		//cout << "Columna: " << stProv.col << endl;
	}

	rodeado = false;
	// accion = actFORWARD;
	last_action = accion;
	return accion;
}

int ComportamientoJugador::interact(Action accion, int valor){
  return false;
}
