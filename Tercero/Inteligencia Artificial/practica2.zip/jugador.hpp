#ifndef COMPORTAMIENTOJUGADOR_H
#define COMPORTAMIENTOJUGADOR_H

#include "comportamientos/comportamiento.hpp"

#include <list>
#include <set>

class stateN0{
  public:
    ubicacion jugador;
    ubicacion sonambulo;

    //HAY QUE MODIFICARLO CUNAOD VENGAN SONAMBULOS Y TAL PORQUE HAY MAS PARAMETROS EN CADA NODO? para el nivel 1
    bool operator==(const stateN0 &st) const{
        return (jugador.f == st.jugador.f && jugador.c == st.jugador.c &&
        sonambulo.f == st.sonambulo.f && sonambulo.c == st.sonambulo.c &&
        jugador.brujula == st.jugador.brujula && sonambulo.brujula == st.sonambulo.brujula);
    }

    bool operator<(const stateN0 &st) const
    {
        return (jugador.f < st.jugador.f ||
               (jugador.f == st.jugador.f && jugador.c < st.jugador.c) ||
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula < st.jugador.brujula));
    }
};

class stateN1: public stateN0{
  public:
    //HAY QUE MODIFICARLO CUNAOD VENGAN SONAMBULOS Y TAL PORQUE HAY MAS PARAMETROS EN CADA NODO? para el nivel 1
    bool operator==(const stateN1 &st) const{
        return (jugador.f == st.jugador.f && jugador.c == st.jugador.c &&
        sonambulo.f == st.sonambulo.f && sonambulo.c == st.sonambulo.c &&
        jugador.brujula == st.jugador.brujula && sonambulo.brujula == st.sonambulo.brujula);
    }

    bool operator<(const stateN1 &st) const
    {
        return (jugador.f < st.jugador.f ||
               (jugador.f == st.jugador.f && jugador.c < st.jugador.c) ||
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula < st.jugador.brujula) ||
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f < st.sonambulo.f) || 
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f == st.sonambulo.f && sonambulo.c < st.sonambulo.c) || 
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f == st.sonambulo.f && sonambulo.c == st.sonambulo.c
               && sonambulo.brujula < st.sonambulo.brujula));
    }
};

//TIENE QUE PONER LO DEL BIKINI Y TAL
// ASI CALCULAR EL COSTE DE MOVERSE A LA SIGUIENTE CASILLA (NODO)
// SEGUIR ALGORITMO A*
class stateN2: public stateN1{
  public:
    bool lleva_zapas;
    bool lleva_bikini;

    stateN2() {
      lleva_zapas = false;
      lleva_bikini = false;
    }

    bool operator==(const stateN2 &st) const{
        return (jugador.f == st.jugador.f && jugador.c == st.jugador.c &&
        sonambulo.f == st.sonambulo.f && sonambulo.c == st.sonambulo.c &&
        jugador.brujula == st.jugador.brujula && sonambulo.brujula == st.sonambulo.brujula
        && lleva_zapas == st.lleva_zapas && lleva_bikini == st.lleva_bikini );
    }

    stateN2 operator=(const stateN1 &st) {
      if(this != &st) {
        lleva_zapas = false;
        lleva_bikini = false;
        jugador = st.jugador;
        sonambulo = st.sonambulo;
      }
      return *this;
    }

    bool operator<(const stateN2 &st) const
    {
        return (jugador.f < st.jugador.f ||
               (jugador.f == st.jugador.f && jugador.c < st.jugador.c) ||
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula < st.jugador.brujula) ||
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f < st.sonambulo.f) || 
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f == st.sonambulo.f && sonambulo.c < st.sonambulo.c) || 
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f == st.sonambulo.f && sonambulo.c == st.sonambulo.c
               && sonambulo.brujula < st.sonambulo.brujula) ||
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f == st.sonambulo.f && sonambulo.c == st.sonambulo.c
               && sonambulo.brujula == st.sonambulo.brujula && lleva_zapas < st.lleva_zapas) || 
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f == st.sonambulo.f && sonambulo.c == st.sonambulo.c
               && sonambulo.brujula == st.sonambulo.brujula && lleva_zapas == st.lleva_zapas && lleva_bikini < st.lleva_bikini));
    }

    bool operator>(const stateN2 &st) const
    {
        return !(operator<(st) or operator==(st));
    }
};

class stateN3: public stateN2{
  public:
    bool son_lleva_zapas;
    bool son_lleva_bikini;

    stateN3() {
      son_lleva_zapas = false;
      son_lleva_bikini = false;
    }

    bool operator==(const stateN3 &st) const{
        return (jugador.f == st.jugador.f && jugador.c == st.jugador.c &&
        sonambulo.f == st.sonambulo.f && sonambulo.c == st.sonambulo.c &&
        jugador.brujula == st.jugador.brujula && sonambulo.brujula == st.sonambulo.brujula
        && lleva_zapas == st.lleva_zapas && lleva_bikini == st.lleva_bikini &&
        son_lleva_zapas == st.son_lleva_zapas && son_lleva_bikini == st.son_lleva_bikini);
    }

    stateN3 operator=(const stateN1 &st) {
      if(this != &st) {
        lleva_zapas = false;
        lleva_bikini = false;
        son_lleva_bikini = false;
        son_lleva_zapas = false;
        jugador = st.jugador;
        sonambulo = st.sonambulo;
      }
      return *this;
    }

    bool operator<(const stateN3 &st) const
    {
        return (jugador.f < st.jugador.f ||
               (jugador.f == st.jugador.f && jugador.c < st.jugador.c) ||
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula < st.jugador.brujula) ||
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f < st.sonambulo.f) || 
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f == st.sonambulo.f && sonambulo.c < st.sonambulo.c) || 
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f == st.sonambulo.f && sonambulo.c == st.sonambulo.c
               && sonambulo.brujula < st.sonambulo.brujula) ||
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f == st.sonambulo.f && sonambulo.c == st.sonambulo.c
               && sonambulo.brujula == st.sonambulo.brujula && lleva_zapas < st.lleva_zapas) || 
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f == st.sonambulo.f && sonambulo.c == st.sonambulo.c
               && sonambulo.brujula == st.sonambulo.brujula && lleva_zapas == st.lleva_zapas && lleva_bikini < st.lleva_bikini) ||
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f == st.sonambulo.f && sonambulo.c == st.sonambulo.c
               && sonambulo.brujula == st.sonambulo.brujula && lleva_zapas == st.lleva_zapas && lleva_bikini == st.lleva_bikini && son_lleva_zapas < st.son_lleva_zapas) || 
               (jugador.f == st.jugador.f && jugador.c == st.jugador.c && jugador.brujula == st.jugador.brujula && sonambulo.f == st.sonambulo.f && sonambulo.c == st.sonambulo.c
               && sonambulo.brujula == st.sonambulo.brujula && lleva_zapas == st.lleva_zapas && lleva_bikini == st.lleva_bikini && son_lleva_zapas == st.son_lleva_zapas &&
               son_lleva_bikini < st.son_lleva_bikini));
    }

    bool operator>(const stateN3 &st) const
    {
        return !(operator<(st) or operator==(st));
    }
};

struct nodeN0{
  stateN0 st;
  list<Action> secuencia;

  bool operator==(const nodeN0 &nd) const{
    return (st == nd.st);
  }

  bool operator<(const nodeN0 &nd) const
  {
    return (st < nd.st);
  }
};

struct nodeN1{
  stateN1 st;
  list<Action> secuencia;

  bool operator==(const nodeN1 &nd) const{
    return (st == nd.st);
  }

  bool operator<(const nodeN1 &nd) const
  {
      return (st < nd.st);
  }
};

struct nodeN2{
  stateN2 st;
  int coste;
  list<Action> secuencia;

  nodeN2(){
    coste = 0;
  }

  bool operator==(const nodeN2 &nd) const{
    return (st == nd.st);
  }

  bool operator<(const nodeN2 &nd) const
  {
      return (coste < nd.coste || (st < nd.st and coste == nd.coste));
  }

  bool operator>(const nodeN2 &nd) const
  {
    return (coste > nd.coste || (st > nd.st and coste == nd.coste));
  }
};

struct nodeN3{
  stateN3 st;
  int costeReal;
  int costeHeur;
  list<Action> secuencia;

  nodeN3(){
    costeReal = 0;
    costeHeur = 0;
  }

  bool operator==(const nodeN3 &nd) const{
    return (st == nd.st);
  }

  bool operator<(const nodeN3 &nd) const
  {
    return (costeReal + costeHeur < nd.costeReal + nd.costeHeur || (st < nd.st and costeReal + costeHeur == nd.costeReal + nd.costeHeur));
  }

  bool operator>(const nodeN3 &nd) const
  {
    return (costeReal + costeHeur > nd.costeReal + nd.costeHeur || (st > nd.st and costeReal + costeHeur == nd.costeReal + nd.costeHeur));
  }
};



class ComportamientoJugador : public Comportamiento {
  public:
    // Nivel 4
    ComportamientoJugador(unsigned int size) : Comportamiento(size) {
      last_ubi. f=size;
      last_ubi.c = size;
      last_ubi.brujula = norte;
      hay_recarga = false;
      last_action = actIDLE;
      c_state.jugador.f = size;
      c_state.jugador.c = size;
      c_state.jugador.brujula = norte;
      c_state.lleva_zapas = false;
      c_state.lleva_bikini = false;
      c_state.sonambulo.f = size;
      c_state.sonambulo.c = size;
      c_state.sonambulo.brujula = norte;
      c_state.son_lleva_bikini = false;
      c_state.son_lleva_zapas;
      bienSituado = false;
      hayPlanBusquedaSonambulo = false;
      hacerPlanBusquedaObjetivo = false;
      hayPlanBusquedaObjetivo = false;
      recargando = false;
      hayPlanBusquedaRecarga = false;
      hacerPlanBusquedaRecarga = false;
      sonambuloEncerrado = false;
      sonambuloInaccesible = false;
      hacerWhereIs = false;
      // Rellenar los precipicios
      for(int i = 0; i < mapaResultado.size(); i++) {
        for(int j = 0; j < 3; j++) {
          mapaResultado[i][j] = 'P';
          mapaResultado[mapaResultado.size()-i-1][mapaResultado.size()-j-1] = 'P';
          mapaResultado[j][i] = 'P';
          mapaResultado[size-j-1][size-i-1] = 'P';
        }
      }
      for(int i = 0; i < 16; i++) {
				last_terreno.push_back('?');
			}
    }
    // Otros niveles
    ComportamientoJugador(std::vector< std::vector< unsigned char> > mapaR) : Comportamiento(mapaR) {
      // Inicializar Variables de Estado
      hayPlan = false;
    }
    ComportamientoJugador(const ComportamientoJugador & comport) : Comportamiento(comport){}
    ~ComportamientoJugador(){}

    Action think(Sensores sensores);
    int interact(Action accion, int valor);


  private:
    // Declarar Variables de Estado

  list<Action> plan;
  //vector<ubicacion> recargas;
  vector<unsigned char> last_terreno;
  ubicacion last_ubi;
  bool hacerWhereIs;
  bool hay_recarga;
  bool hayPlan;
  bool hayPlanBusquedaSonambulo;
  bool hacerPlanBusquedaObjetivo;
  bool hayPlanBusquedaObjetivo;
  bool recargando;
  bool hayPlanBusquedaRecarga;
  bool hacerPlanBusquedaRecarga;
  bool sonambuloEncerrado;
  bool sonambuloInaccesible;
  stateN3 c_state;
  ubicacion goal;
  void VisualizaPlan(const stateN0 &st, const list<Action> &plan);
  Action last_action;
  bool bienSituado;
};

list<Action> AvanzaASaltosDeCaballo();
bool CasillaTransitable(const ubicacion &x, const vector<vector<unsigned char>> &mapa);
ubicacion NextCasilla(const ubicacion &pos);
stateN0 apply(const Action &a, const stateN0 &st, const vector<vector<unsigned char>> &mapa);
bool Find(const stateN0 &item, const list<stateN0> &lista);
list<Action> AnchuraSoloJugador(const stateN0 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa);
bool Find(const stateN0 &item, const list<nodeN0> &lista);
void VisualizaPlan(const stateN0 &st, const list<Action> &plan);
void AnularMatriz(vector<vector<unsigned char>> &matriz);
stateN1 apply(const Action &a, const stateN1 &st, const vector<vector<unsigned char>> &mapa);
bool JugadorVeSonambulo(const stateN0 &st, const vector<vector<unsigned char>> &mapa);
list<Action> AnchuraSoloJugadorN1(const stateN1 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa);
list<Action> CosteUniforme(const stateN2 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa);
int CalcularCoste(const stateN2 &current_node, Action action, const vector<vector<unsigned char>> &mapa);
int HeuristicaMaximo(ubicacion sonambulo, ubicacion objetivo);
list<Action> AEstrella(const stateN3 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa);
int CalcularCoste(const stateN3 &current_node, Action action, const vector<vector<unsigned char>> &mapa);
stateN3 apply(const Action &a, const stateN3 &st, const vector<vector<unsigned char>> &mapa);
void PonerTerrenoEnMatriz(const vector<unsigned char> &terreno, const stateN3 &st, vector < vector <unsigned char> > &matriz);
void ActualizarEstado(Action last_action, stateN3 &current_state, ubicacion &goal, Sensores sensores);
//list<Action> AlgoritmoNivel4(const stateN3 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa);
//list<Action> AlgoritmoNivel4MapaConocido(const stateN3 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa);
list<Action> AlgoritmoNivel4MapaDesconocido(const stateN3 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa);
int CosteNivel4(const stateN3 &current_node, Action action, const vector<vector<unsigned char>> &mapa);
bool JugadorVeDelanteSonambulo(const stateN0 &st, const vector<vector<unsigned char>> &mapa);
list<Action> BusquedaSonambulo(const stateN3 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa, stateN3 &finalJugador);
stateN3 applyNivel4(const Action &a, const stateN3 &st, const vector<vector<unsigned char>> &mapa);
bool AlguienDelanteSonambulo(const stateN3 &st,Sensores sensores);
bool CasillaNotWorthy(const ubicacion &ubicacion, const vector<vector<unsigned char>> &mapa, bool zapas, bool bikini);
int HeuristicaManhattan(ubicacion sonambulo, ubicacion objetivo);
stateN3 applyBusquedaSonam(const Action &a, const stateN3 &st, const vector<vector<unsigned char>> &mapa);
bool BuscarNuevoPlan(Action accion, Action last_action, const stateN3 &c_state, const vector<vector<unsigned char>> &mapaResultado);
ubicacion Casilla(char caracter, ubicacion ubi, Sensores sensores);
list<Action> BusquedaRecarga(const stateN3 &inicio,const vector<vector<unsigned char>> &mapa);
ubicacion BuscarRecargaCercana(const stateN3& c_state,vector<ubicacion> recargas);
bool VeRecarga(Sensores sensores);
bool ContenidoVector(vector<ubicacion> vector,ubicacion ubi);
bool UbicacionesCercanas(ubicacion ubi1, ubicacion ubi2);
list<Action> BusquedaObjetivo(const stateN3 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa);
ubicacion CalcularDestino(int n, ubicacion lastUbi);
ubicacion CalcularNuevaPosicion(vector<unsigned char> ultima, vector<unsigned char> actual,ubicacion lastUbi);
stateN3 applyObjetivoSonam(const Action &a, const stateN3 &st, const vector<vector<unsigned char>> &mapa);
list<Action> BusquedaObjetivoSonam(const stateN3 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa) ;
bool MapaConocido(const vector<vector<unsigned char>> &mapaResultado, list<Action> plan,stateN3 inicio);

#endif
