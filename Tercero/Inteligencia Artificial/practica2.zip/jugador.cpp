#include "../Comportamientos_Jugador/jugador.hpp"
#include "motorlib/util.h"

#include <iostream>
#include <cmath>
#include <set>
#include <stack>
#include<queue>

// Este es el método principal que se piden en la practica.
// Tiene como entrada la información de los sensores y devuelve la acción a realizar.
// Para ver los distintos sensores mirar fichero "comportamiento.hpp"
Action ComportamientoJugador::think(Sensores sensores)
{
	Action accion = actIDLE;
	if(sensores.nivel != 4) {
		if (!hayPlan){
			cout << "Calculando plan..." << endl;
			c_state.jugador.f = sensores.posF;
			c_state.jugador.c = sensores.posC;
			c_state.jugador.brujula = sensores.sentido;
			c_state.sonambulo.f = sensores.SONposF;
			c_state.sonambulo.c = sensores.SONposC;
			c_state.sonambulo.brujula = sensores.SONsentido;
			goal.f = sensores.destinoF;
			goal.c = sensores.destinoC;
			switch (sensores.nivel) {
				case 0: 
					plan = AnchuraSoloJugador(c_state, goal, mapaResultado);
					break;
				case 1:
					plan = AnchuraSoloJugadorN1(c_state, goal, mapaResultado);
					break;
				case 2:
					plan = CosteUniforme(c_state,goal,mapaResultado);
					break;
				case 3:
					plan = AEstrella(c_state,goal,mapaResultado);
					break;
			}

			if(plan.size() > 0) {
				cout << "plan encontrado" << endl;
				VisualizaPlan(c_state,plan);
				hayPlan = true;
			}
		}
		if (hayPlan and plan.size()>0){
			cout << "Ejecutando siguiente acción del plan" << endl;
			accion = plan.front();
			plan.pop_front();
		}

		if (plan.size()== 0){
			cout << "Se completó el plan" << endl;
			hayPlan = false;
		}
	} else { // NIVEL 4
		if(!bienSituado){
			if(sensores.vida == 2999) {
				accion = actWHEREIS;
			} else {
				ubicacion actual = CalcularNuevaPosicion(last_terreno,sensores.terreno,c_state.jugador);
				if(actual.f == -1 or actual.c == -1 or hacerWhereIs) {
					accion = actWHEREIS;
					hacerWhereIs = false;
				} else {
					c_state.jugador.f = actual.f;
					c_state.jugador.c = actual.c;
					c_state.jugador.brujula = actual.brujula;
					bienSituado = false;
					// ubicacion sonam = Casilla('s',c_state.jugador,sensores);
					// if(sonam.f != actual.f or sonam.c != actual.c) {
					// 	c_state.sonambulo.f = sonam.f;
					// 	c_state.sonambulo.c = sonam.c;
					// }
				}
				if(sonambuloInaccesible) hacerPlanBusquedaObjetivo = true;
				else hacerPlanBusquedaObjetivo = false;
				hayPlanBusquedaObjetivo = false;
				hayPlanBusquedaSonambulo = false;
				hayPlanBusquedaRecarga = false;
				recargando = false;
				hacerPlanBusquedaRecarga = false;
			}
			bienSituado = true;
		}else {
			ActualizarEstado(last_action,c_state,goal,sensores);
			if(sensores.colision) {
				bienSituado = false;
				if(sonambuloInaccesible) hacerPlanBusquedaObjetivo = true;
				else hacerPlanBusquedaObjetivo = false;
				hayPlanBusquedaObjetivo = false;
				hayPlanBusquedaSonambulo = false;
				hayPlanBusquedaRecarga = false;
				recargando = false;
				hacerPlanBusquedaRecarga = false;
				if(sensores.vida == 2999 or last_action == actFORWARD or last_action == actTURN_L or last_action == actTURN_R){
					hacerWhereIs = true;
				}
			} else {
				PonerTerrenoEnMatriz(sensores.terreno,c_state,mapaResultado);
			}

			if(!hayPlanBusquedaSonambulo and !hacerPlanBusquedaObjetivo and !hayPlanBusquedaObjetivo and !hayPlanBusquedaRecarga and !hacerPlanBusquedaRecarga and !recargando and bienSituado and !sonambuloInaccesible) {
				goal.f = sensores.destinoF;
				goal.c = sensores.destinoC;
				cout << "Buscando plan para ver si el sonambulo esta encerrado" << endl;
				plan = BusquedaObjetivoSonam(c_state,goal,mapaResultado);
				if(!plan.empty()) {
					//VisualizaPlan(c_state,plan);
					plan.clear();
					cout << "Buscando plan para encontrar al sonámbulo" << endl;
					stateN3 finalJugador; //solo se va a modificar
					plan = BusquedaSonambulo(c_state,goal,mapaResultado,finalJugador);

					if(plan.size() > 0) {
						if(MapaConocido(mapaResultado,plan,c_state) and finalJugador.jugador.f <= mapaResultado.size() and finalJugador.jugador.c >= 0 and 
						finalJugador.sonambulo.f >= 0 and finalJugador.sonambulo.c <= mapaResultado.size()) {
							cout << "Comprobando si merece la pena buscar al sonambulo" << endl;
							list<Action> posiblePlan = AlgoritmoNivel4MapaDesconocido(finalJugador,goal,mapaResultado);
							if(posiblePlan.empty()) {
								cout << "No merece la pena buscarlo" << endl;
								hacerPlanBusquedaObjetivo = true;
								sonambuloEncerrado = true;
							} else {
								cout << "Merece la pena buscarlo y plan encontrado" << endl;
								VisualizaPlan(c_state,plan);
								hayPlanBusquedaSonambulo = true;
							}
						} else {
							cout << "No conocemos suficiente el mapa y plan encontrado" << endl;
							VisualizaPlan(c_state,plan);
							hayPlanBusquedaSonambulo = true;
						}
						
					} else if(JugadorVeDelanteSonambulo(c_state,mapaResultado)){
						hacerPlanBusquedaObjetivo = true;
					} else {
						sonambuloInaccesible = true;
						hacerPlanBusquedaObjetivo = true;
					}
				} else {
					hacerPlanBusquedaObjetivo = true;
					sonambuloEncerrado = true;
					plan.clear();
				}
			} 
			
			if(hacerPlanBusquedaObjetivo and bienSituado and !sonambuloInaccesible) {
				goal.f = sensores.destinoF;
				goal.c = sensores.destinoC;
				cout << "Buscando plan para que el sonambulo llegue al objetivo" << endl;
				plan = AlgoritmoNivel4MapaDesconocido(c_state,goal,mapaResultado);
				if(plan.empty() and !sonambuloEncerrado) {
					sonambuloEncerrado = true;
				}
				if(plan.size() > 0) {
					cout << "plan encontrado" << endl;
					VisualizaPlan(c_state,plan);
					hayPlanBusquedaObjetivo = true;
					hacerPlanBusquedaObjetivo = false;
					hayPlanBusquedaSonambulo = false;
					recargando = false;
					hayPlanBusquedaRecarga = false;
					hacerPlanBusquedaRecarga = false;
				} else {
					hayPlanBusquedaObjetivo = false;
					//hacerPlanBusquedaObjetivo = false;
					hayPlanBusquedaSonambulo = false;
					hacerPlanBusquedaRecarga = false;
					recargando = false;
					hayPlanBusquedaRecarga = false;
				}
			} 
			
			if(hacerPlanBusquedaObjetivo and bienSituado and (sonambuloEncerrado or sonambuloInaccesible)) {
				goal.f = sensores.destinoF;
				goal.c = sensores.destinoC;
				cout << "Buscando plan para que el jugador llegue al objetivo" << endl;

				plan = BusquedaObjetivo(c_state,goal,mapaResultado);
				if(plan.size() > 0) {
					cout << "plan encontrado" << endl;
					VisualizaPlan(c_state,plan);
					hayPlanBusquedaObjetivo = true;
					hacerPlanBusquedaObjetivo = false;
					hayPlanBusquedaSonambulo = false;
					recargando = false;
					hayPlanBusquedaRecarga = false;
					hacerPlanBusquedaRecarga = false;
				}

			}

			if(!hayPlanBusquedaRecarga && !(mapaResultado[c_state.sonambulo.f][c_state.sonambulo.c]=='X') &&!recargando && bienSituado &&(sensores.bateria <= 1200 and hay_recarga and sensores.vida > 750) or 
				(hacerPlanBusquedaRecarga and !hayPlanBusquedaObjetivo and !hayPlanBusquedaSonambulo and !hacerPlanBusquedaObjetivo)) {
				hayPlanBusquedaObjetivo = false;
				hayPlanBusquedaSonambulo = false;
				hacerPlanBusquedaObjetivo = false;
				hacerPlanBusquedaRecarga = false; 
				recargando = false;
				//ubicacion recarga = BuscarRecargaCercana(c_state,recargas);
				plan = BusquedaRecarga(c_state,mapaResultado);

				if(plan.size() > 0) {
					cout << "plan encontrado" << endl;
					VisualizaPlan(c_state,plan);
					hayPlanBusquedaRecarga = true;
				}
			}

			if ((hayPlanBusquedaSonambulo or hayPlanBusquedaObjetivo or hayPlanBusquedaRecarga) and !recargando and plan.size()>0 and bienSituado){
				cout << "Ejecutando siguiente acción del plan" << endl;
				accion = plan.front();
				if((AlguienDelanteSonambulo(c_state,sensores) && accion == actSON_FORWARD) || (accion == actFORWARD && sensores.superficie[2] != '_')) {
					cout << "cvshevdakzjxvb" << endl;
					accion = actIDLE;
				} else {
					plan.pop_front();
				}
				
				if(BuscarNuevoPlan(accion,last_action,c_state,mapaResultado)) {
					//cout << "Buscar nuevo plan"  << endl;
					if(JugadorVeDelanteSonambulo(c_state,mapaResultado) && !hayPlanBusquedaRecarga) {
						hayPlanBusquedaSonambulo = false;
						hacerPlanBusquedaObjetivo = true;
						hayPlanBusquedaObjetivo = false;
						hayPlanBusquedaRecarga = false;
						recargando = false;
						hacerPlanBusquedaRecarga = false;
					} else if(!JugadorVeDelanteSonambulo(c_state,mapaResultado) and !hayPlanBusquedaRecarga && !sonambuloEncerrado and !sonambuloInaccesible){
						hacerPlanBusquedaObjetivo = false;
						hayPlanBusquedaObjetivo = false;
						hayPlanBusquedaSonambulo = false;
						hayPlanBusquedaRecarga = false;
						recargando = false;
						hacerPlanBusquedaRecarga = false;
					}else if (!JugadorVeDelanteSonambulo(c_state,mapaResultado) and !hayPlanBusquedaRecarga && (sonambuloEncerrado or sonambuloInaccesible)) {
						hacerPlanBusquedaRecarga = false;
						hacerPlanBusquedaObjetivo = true;
						hayPlanBusquedaObjetivo = false;
						hayPlanBusquedaSonambulo = false;
						hayPlanBusquedaRecarga = false;
						recargando = false;
					} else {
						hacerPlanBusquedaRecarga = true;
						hacerPlanBusquedaObjetivo = false;
						hayPlanBusquedaObjetivo = false;
						hayPlanBusquedaSonambulo = false;
						hayPlanBusquedaRecarga = false;
						recargando = false;
					}
					accion = actIDLE;
					plan.clear();
				}
			} else if(recargando and bienSituado) {
				if(sensores.bateria <= 2*sensores.vida && sensores.bateria<3000) {
					accion = actIDLE;
				} else {
					recargando = false;
					if(!JugadorVeDelanteSonambulo(c_state,mapaResultado) and !sonambuloInaccesible) {
						hayPlanBusquedaObjetivo = false;
						hayPlanBusquedaSonambulo = false;
						hayPlanBusquedaRecarga = false;
						hacerPlanBusquedaObjetivo = false;
						hacerPlanBusquedaRecarga = false;
					} else {
						hacerPlanBusquedaObjetivo = true;
						hayPlanBusquedaObjetivo = false;
						hayPlanBusquedaSonambulo = false;
						hayPlanBusquedaRecarga = false;
						hacerPlanBusquedaRecarga = false;
					}
				}
			}

			if(!hay_recarga and VeRecarga(sensores) and bienSituado) {
				hay_recarga = true;
			}

			if (hayPlanBusquedaSonambulo and plan.size()== 0 and bienSituado){
				cout << "Se completó el plan" << endl;
				hayPlanBusquedaSonambulo = false;
				hacerPlanBusquedaObjetivo = true;
				cout << "se ha terminado de buscar al sonambulo" << endl;
				//if(!JugadorVeDelanteSonambulo(c_state,mapaResultado))	sonambuloEncerrado = true;
			} else if(hayPlanBusquedaObjetivo and plan.size() == 0 and bienSituado) {
				cout << "Se completó el plan" << endl;
				hayPlanBusquedaObjetivo = false;
				if(JugadorVeDelanteSonambulo(c_state,mapaResultado) and bienSituado and !sonambuloEncerrado and !sonambuloInaccesible) {
					hacerPlanBusquedaObjetivo = true;
				}
				if(sonambuloInaccesible) hacerPlanBusquedaObjetivo = true;
			} else if(hayPlanBusquedaRecarga and plan.size() == 0 and bienSituado) {
				cout << "Se completó el plan" << endl;
				hayPlanBusquedaRecarga = false;
				recargando = true;
				//if(sonambuloInaccesible) hacerPlanBusquedaObjetivo = true;
			}
		}
		last_action = accion;	
		if(bienSituado and sensores.vida !=2999) {
			last_ubi.f = c_state.jugador.f;
			last_ubi.c = c_state.jugador.c;
			last_ubi.brujula = c_state.jugador.brujula;
			for(int i = 0; i < 16; i++) {
				last_terreno[i] = sensores.terreno[i];
			}
		}
	}
	return accion;
}

bool MapaConocido(const vector<vector<unsigned char>> &mapaResultado, list<Action> plan,stateN3 inicio) {
	bool conozcoMapa = true;
	stateN3 sigState = inicio;
	while(plan.size()>0 and conozcoMapa) {
		Action accion = plan.front();
		plan.pop_front();
		sigState = applyBusquedaSonam(accion,sigState,mapaResultado);
		if(mapaResultado[sigState.jugador.f][sigState.jugador.c] == '?') {
			conozcoMapa = false;
		}
	}

	return conozcoMapa;
}

bool VeRecarga(Sensores sensores) {
	int posRec = -1;
	for(int i = 1; i < 16 && posRec == -1; i++) {
		if(sensores.terreno[i] == 'X') posRec = i;
	}
	return posRec != -1;
}

bool ContenidoVector(vector<ubicacion> vector,ubicacion ubi) {
	for(int i = 0; i < vector.size(); i++) {
		if(vector[i] == ubi) {
			return true;
		}
	}
	return false;
}

bool BuscarNuevoPlan(Action accion, Action last_action, const stateN3 &c_state, const vector<vector<unsigned char>> &mapaResultado) {

	return (accion == actFORWARD && last_action!=actIDLE && CasillaNotWorthy(NextCasilla(c_state.jugador),mapaResultado,c_state.lleva_zapas,c_state.lleva_bikini) && !CasillaNotWorthy(c_state.jugador,mapaResultado,c_state.lleva_zapas,c_state.lleva_bikini)) 
	|| (accion == actSON_FORWARD && last_action!=actIDLE && CasillaNotWorthy(NextCasilla(c_state.sonambulo),mapaResultado,c_state.son_lleva_zapas,c_state.son_lleva_bikini) && !CasillaNotWorthy(c_state.sonambulo,mapaResultado,c_state.son_lleva_zapas,c_state.son_lleva_bikini))
	|| (accion == actFORWARD && !CasillaTransitable(NextCasilla(c_state.jugador),mapaResultado))
	|| (accion == actSON_FORWARD && !CasillaTransitable(NextCasilla(c_state.sonambulo),mapaResultado));
}

list<Action> AvanzaASaltosDeCaballo(){
	list<Action> secuencia;
	secuencia.push_back(actFORWARD);
	secuencia.push_back(actFORWARD);
	secuencia.push_back(actTURN_R);
    secuencia.push_back(actFORWARD);
	return secuencia;
}

/** Devuelve si una ubicación en el mapa es transitable para el agente */
bool CasillaTransitable(const ubicacion &x, const vector<vector<unsigned char>> &mapa)
{
	return (mapa[x.f][x.c] != 'P' and mapa[x.f][x.c] != 'M');
}

bool CasillaNotWorthy(const ubicacion &ubicacion, const vector<vector<unsigned char>> &mapa, bool zapas, bool bikini)
{
	if (mapa[ubicacion.f][ubicacion.c] == 'P' or mapa[ubicacion.f][ubicacion.c] == 'M') return true;
	else if(!zapas and mapa[ubicacion.f][ubicacion.c] == 'B') return true;
	else if(!bikini and mapa[ubicacion.f][ubicacion.c] == 'A') return true;
	return false;
}

/** Devuelve la ubicación siguiente según el avance del agente*/
ubicacion NextCasilla(const ubicacion &pos)
{
	ubicacion next = pos;
	switch (pos.brujula)
	{
	case norte:
		next.f = pos.f - 1;
		break;
	case noreste:
		next.f = pos.f - 1;
		next.c = pos.c + 1;
		break;
	case este:
		next.c = pos.c + 1;
		break;
	case sureste:
		next.f = pos.f + 1;
		next.c = pos.c + 1;
		break;
	case sur:
		next.f = pos.f + 1;
		break;
	case suroeste:
		next.f = pos.f + 1;
		next.c = pos.c - 1;
		break;
	case oeste:
		next.c = pos.c - 1;
		break;
	case noroeste:
		next.f = pos.f - 1;
		next.c = pos.c - 1;
		break;
	default:
		break;
	}

	return next;
}

// HAY QUE MODIFICAR EL APPLY PARA EL NIVEL 1 Y ANCHUR PARTICULAR PARA EL NIVEL 1
// las acciones de los hijos? solo funcionarán cauando el jugadore este cerca
// para saber si está el sonambulo en la vista de jugador
// for(int i = 1; i < 3; i++) {
//		for(int j = -1; j <= i; j++) {
//			//este es un ejemplo pal norte 
//		}
//}


/** Devuelve el estado que se genera si el agente puede avanzar.
 * Si no puede avanzar, se devuelve como salida el mismo estado de entrada.
 */
stateN0 apply(const Action &a, const stateN0 &st, const vector<vector<unsigned char>> &mapa)
{
  stateN0 st_result = st;
  ubicacion sig_ubicacion;
  switch (a){
	case actFORWARD: // si casilla delante es transitable y no está ocupada por el sonámbulo
		sig_ubicacion = NextCasilla(st.jugador);
		if (CasillaTransitable(sig_ubicacion, mapa) and !(sig_ubicacion.f == st.sonambulo.f and sig_ubicacion.c == st.sonambulo.c)){
			st_result.jugador = sig_ubicacion;
		}
		break;
	case actTURN_L:
		st_result.jugador.brujula = static_cast<Orientacion>((st_result.jugador.brujula + 6) % 8);
		break;

	case actTURN_R:
		st_result.jugador.brujula = static_cast<Orientacion>((st_result.jugador.brujula + 2) % 8);
		break;
  }
  return st_result;
}
/** Devuelve el estado que se genera si el sonambulo puede avanzar.
 * Si no puede avanzar, se devuelve como salida el mismo estado de entrada.
 */
stateN1 apply(const Action &a, const stateN1 &st, const vector<vector<unsigned char>> &mapa)
{
  stateN1 st_result = st;
  ubicacion sig_ubicacion;
  switch (a){
	case actFORWARD: // si casilla delante es transitable y no está ocupada por el sonámbulo
		sig_ubicacion = NextCasilla(st.jugador);
		if (CasillaTransitable(sig_ubicacion, mapa) and !(sig_ubicacion.f == st.sonambulo.f and sig_ubicacion.c == st.sonambulo.c)){
			st_result.jugador = sig_ubicacion;
		}
		break;
	case actTURN_L:
		st_result.jugador.brujula = static_cast<Orientacion>((st_result.jugador.brujula + 6) % 8);
		break;

	case actTURN_R:
		st_result.jugador.brujula = static_cast<Orientacion>((st_result.jugador.brujula + 2) % 8);
		break;
	case actSON_FORWARD:
		sig_ubicacion = NextCasilla(st.sonambulo);
		if(CasillaTransitable(sig_ubicacion, mapa) and JugadorVeSonambulo(st_result, mapa) and !(sig_ubicacion.f == st.jugador.f and sig_ubicacion.c == st.jugador.c)) {
			st_result.sonambulo = sig_ubicacion;
		}
		break;
	case actSON_TURN_SL:
		if(JugadorVeSonambulo(st_result,mapa)) {
			st_result.sonambulo.brujula = static_cast<Orientacion>((st_result.sonambulo.brujula + 7) % 8);
		}
		break;
	case actSON_TURN_SR:
		if(JugadorVeSonambulo(st_result,mapa)) {
			st_result.sonambulo.brujula = static_cast<Orientacion>((st_result.sonambulo.brujula + 1) % 8);
		}
		break;
  }
  return st_result;
}

//TERMINAR CON LAS ACCIONES DEL SONAMBULO
stateN2 apply(const Action &a, const stateN2 &st, const vector<vector<unsigned char>> &mapa)
{
  stateN2 st_result = st;
  ubicacion sig_ubicacion;
  switch (a){
	case actIDLE:
		if(mapa[st.jugador.f][st.jugador.c] == 'D') {
			st_result.lleva_zapas = true;
			st_result.lleva_bikini = false;
		} else if(mapa[st.jugador.f][st.jugador.c] == 'K') {
			st_result.lleva_zapas = false;
			st_result.lleva_bikini = true;
		}
			break;
	case actFORWARD: // si casilla delante es transitable y no está ocupada por el sonámbulo
		sig_ubicacion = NextCasilla(st.jugador);
		if (CasillaTransitable(sig_ubicacion, mapa) and !(sig_ubicacion.f == st.sonambulo.f and sig_ubicacion.c == st.sonambulo.c) ){
			st_result.jugador = sig_ubicacion;
			if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'D') {
				st_result.lleva_zapas = true;
				st_result.lleva_bikini = false;
			} else if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'K') {
				st_result.lleva_zapas = false;
				st_result.lleva_bikini = true;
			}
		}
		break;
	case actTURN_L:
		st_result.jugador.brujula = static_cast<Orientacion>((st_result.jugador.brujula + 6) % 8);
		break;

	case actTURN_R:
		st_result.jugador.brujula = static_cast<Orientacion>((st_result.jugador.brujula + 2) % 8);
		break;
  }
  return st_result;
}

stateN3 apply(const Action &a, const stateN3 &st, const vector<vector<unsigned char>> &mapa)
{
 	stateN3 st_result = st;
	ubicacion sig_ubicacion;
	switch (a){
		case actIDLE:
			if(mapa[st.jugador.f][st.jugador.c] == 'D') {
				st_result.lleva_zapas = true;
				st_result.lleva_bikini = false;
			} else if(mapa[st.jugador.f][st.jugador.c] == 'K') {
				st_result.lleva_zapas = false;
				st_result.lleva_bikini = true;
			}
			if(mapa[st.sonambulo.f][st.sonambulo.c] == 'D') {
				st_result.son_lleva_zapas = true;
				st_result.son_lleva_bikini = false;
			} else if(mapa[st.sonambulo.f][st.sonambulo.c] == 'K') {
				st_result.son_lleva_zapas = false;
				st_result.son_lleva_bikini = true;
			}
			break;
		case actFORWARD: // si casilla delante es transitable y no está ocupada por el sonámbulo
			sig_ubicacion = NextCasilla(st.jugador);
			if (CasillaTransitable(sig_ubicacion, mapa) and !(sig_ubicacion.f == st.sonambulo.f and sig_ubicacion.c == st.sonambulo.c)){
				st_result.jugador = sig_ubicacion;
				if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'D') {
					st_result.lleva_zapas = true;
					st_result.lleva_bikini = false;
				} else if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'K') {
					st_result.lleva_zapas = false;
					st_result.lleva_bikini = true;
				}
			}
			break;
		case actTURN_L:
			st_result.jugador.brujula = static_cast<Orientacion>((st_result.jugador.brujula + 6) % 8);
			break;

		case actTURN_R:
			st_result.jugador.brujula = static_cast<Orientacion>((st_result.jugador.brujula + 2) % 8);
			break;
		case actSON_FORWARD:
			sig_ubicacion = NextCasilla(st.sonambulo);
			if(CasillaTransitable(sig_ubicacion, mapa) and JugadorVeSonambulo(st, mapa) and !(sig_ubicacion.f == st.jugador.f and sig_ubicacion.c == st.jugador.c)) {
				st_result.sonambulo = sig_ubicacion;
				if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'D') {
					st_result.son_lleva_zapas = true;
					st_result.son_lleva_bikini = false;
				} else if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'K') {
					st_result.son_lleva_zapas = false;
					st_result.son_lleva_bikini = true;
				}
			}
			break;
		case actSON_TURN_SL:
			if(JugadorVeSonambulo(st_result,mapa)) {
				st_result.sonambulo.brujula = static_cast<Orientacion>((st_result.sonambulo.brujula + 7) % 8);
			}
			break;
		case actSON_TURN_SR:
			if(JugadorVeSonambulo(st_result,mapa)) {
				st_result.sonambulo.brujula = static_cast<Orientacion>((st_result.sonambulo.brujula + 1) % 8);
			}
			break;
	}
	return st_result; 
}

bool JugadorVeSonambulo(const stateN0 &st, const vector<vector<unsigned char>> &mapa) 
{
	int filaSon = st.sonambulo.f;
	int colSon = st.sonambulo.c;
	int filaJug = st.jugador.f;
	int colJug = st.jugador.c;

	switch(st.jugador.brujula) {
		case norte:
			for(int i = -1; i >= -3; i--) {
				for(int j = i; j <= -i; j++) {
					if(filaJug + i == filaSon and colJug + j == colSon) return true;
				}
			}
		break;
		case sur:
			for(int i = 1; i <= 3; i++){
				for(int j = i; j >= -i; j--) {
					if(filaJug + i == filaSon and colJug + j == colSon) return true;
				}
			}
		break;
		case este:
			for(int j = 1; j <= 3; j++){
				for(int i = -j; i <= j; i++) {
					if(filaJug + i == filaSon and colJug + j == colSon) return true;				
				}
			}
		break;
		case oeste:
			for(int j = -1; j >= -3; j--){
				for(int i = -j; i >= j; i--) {
					if(filaJug + i == filaSon and colJug + j == colSon) return true;				
				}
			}
		break;
	}

	return false;
}

bool JugadorVeDelanteSonambulo(const stateN0 &st, const vector<vector<unsigned char>> &mapa) 
{
	int filaSon = NextCasilla(st.sonambulo).f;
	int colSon = NextCasilla(st.sonambulo).c;
	int filaJug = st.jugador.f;
	int colJug = st.jugador.c;

	switch(st.jugador.brujula) {
		case norte:
			for(int i = -1; i >= -3; i--) {
				for(int j = i; j <= -i; j++) {
					if(filaJug + i == filaSon and colJug + j == colSon) return true;
				}
			}
		break;
		case sur:
			for(int i = 1; i <= 3; i++){
				for(int j = i; j >= -i; j--) {
					if(filaJug + i == filaSon and colJug + j == colSon) return true;
				}
			}
		break;
		case este:
			for(int j = 1; j <= 3; j++){
				for(int i = -j; i <= j; i++) {
					if(filaJug + i == filaSon and colJug + j == colSon) return true;				
				}
			}
		break;
		case oeste:
			for(int j = -1; j >= -3; j--){
				for(int i = -j; i >= j; i--) {
					if(filaJug + i == filaSon and colJug + j == colSon) return true;				
				}
			}
		break;
	}

	return false;
}


/** Encuentra si el elmento item está en lista */
bool Find(const stateN0 &item, const list<stateN0> &lista)
{
  auto it = lista.begin();
  while (it != lista.end() and !((*it) == item))
    it++;

  return (!(it == lista.end()));
}

bool Find(const stateN0 &item, const list<nodeN0> &lista)
{
  auto it = lista.begin();
  while (it != lista.end() and !((*it).st == item))
    it++;

  return (!(it == lista.end()));
}

/** primera aproximación a la implimentación de la busqueda en anchura */
list<Action> AnchuraSoloJugador(const stateN0 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa)
{
	nodeN0 current_node;
	current_node.st = inicio;
	list<nodeN0> frontier;
	set<nodeN0> explored;
	list<Action> plan;
	bool SolutionFound = (current_node.st.jugador.f == final.f and current_node.st.jugador.c == final.c);
	frontier.push_back(current_node);
	
	while (!frontier.empty() and !SolutionFound)
	{
		frontier.pop_front();
		explored.insert(current_node);

		// Generar hijo actFORWARD
		nodeN0 child_forward = current_node; 
		child_forward.st = apply(actFORWARD, current_node.st, mapa);
		if (child_forward.st.jugador.f == final.f and child_forward.st.jugador.c == final.c)
		{
			child_forward.secuencia.push_back(actFORWARD); 
			current_node = child_forward;
			SolutionFound = true;
		}
		else if (explored.find(child_forward) == explored.end())
		{
			child_forward.secuencia.push_back(actFORWARD);
			frontier.push_back(child_forward);
		}

		if (!SolutionFound)
		{
			// Generar hijo actTURN_L
			nodeN0 child_turnl = current_node; 
			child_turnl.st = apply(actTURN_L, current_node.st, mapa);
			if (explored.find(child_turnl) == explored.end())
			{
				child_turnl.secuencia.push_back(actTURN_L);
				frontier.push_back(child_turnl);
			}
			// Generar hijo actTURN_R
			nodeN0 child_turnr = current_node;
			child_turnr.st = apply(actTURN_R, current_node.st, mapa);
			if (explored.find(child_turnr) == explored.end())
			{
				child_turnr.secuencia.push_back(actTURN_R);
				frontier.push_back(child_turnr);
			}
		}

		if (!SolutionFound and !frontier.empty())
		{
			current_node = frontier.front();
			while(!frontier.empty() and explored.find(current_node) != explored.end()){
				frontier.pop_front();
				current_node = frontier.front();
			}
		}
	}

	if(SolutionFound){ 
		plan = current_node.secuencia;
	}

	return plan;
}

list<Action> AnchuraSoloJugadorN1(const stateN1 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa)
{
	nodeN1 current_node;
	current_node.st = inicio; 
	list<nodeN1> frontier;
	set<nodeN1> explored;
	list<Action> miPlan;
	bool SolutionFound = (current_node.st.sonambulo.f == final.f and current_node.st.sonambulo.c == final.c);
	frontier.push_back(current_node); 

	while (!frontier.empty() and !SolutionFound)
	{
		frontier.pop_front();
		explored.insert(current_node);

		// Generar hijo actSON_FORWARD
		nodeN1 child_son_forward = current_node;
		child_son_forward.st = apply(actSON_FORWARD, current_node.st, mapa);
		if (child_son_forward.st.sonambulo.f == final.f and child_son_forward.st.sonambulo.c == final.c)
		{
			child_son_forward.secuencia.push_back(actSON_FORWARD); 
			current_node = child_son_forward;
			//TENER CUIDADO CUANDO NO ES ANCHURA PQ ESTÁ ACABANDO EN ABIERTOS
			SolutionFound = true;
		}
		else if (explored.find(child_son_forward) == explored.end())
		{
			child_son_forward.secuencia.push_back(actSON_FORWARD);
			frontier.push_back(child_son_forward);
		}

		if (!SolutionFound)
		{
			// Generar hijo actFORWARD
			nodeN1 child_forward = current_node;
			child_forward.st = apply(actFORWARD,current_node.st,mapa);
			if(explored.find(child_forward) == explored.end()) {
				child_forward.secuencia.push_back(actFORWARD);
				frontier.push_back(child_forward);
			}

			// Generar hijo actSOn_turnl
			nodeN1 child_son_turnl = current_node;
			child_son_turnl.st = apply(actSON_TURN_SL, current_node.st, mapa);
			if(explored.find(child_son_turnl) == explored.end()) {
				child_son_turnl.secuencia.push_back(actSON_TURN_SL);
				frontier.push_back(child_son_turnl);
			}

			// Generar hijo actSON_turnr
			nodeN1 child_son_turnr = current_node;
			child_son_turnr.st = apply(actSON_TURN_SR, current_node.st, mapa);
			if(explored.find(child_son_turnr) == explored.end()) {
				child_son_turnr.secuencia.push_back(actSON_TURN_SR);
				frontier.push_back(child_son_turnr);
			}

			// Generar hijo actTURN_L
			nodeN1 child_turnl = current_node;
			child_turnl.st = apply(actTURN_L, current_node.st, mapa);
			if (explored.find(child_turnl) == explored.end())
			{
				child_turnl.secuencia.push_back(actTURN_L);
				frontier.push_back(child_turnl);
			}
			// Generar hijo actTURN_R
			nodeN1 child_turnr = current_node; 
			child_turnr.st = apply(actTURN_R, current_node.st, mapa);
			if (explored.find(child_turnr) == explored.end())
			{
				child_turnr.secuencia.push_back(actTURN_R);
				frontier.push_back(child_turnr);
			}
		}

		if (!SolutionFound and !frontier.empty())
		{
			current_node = frontier.front();
			while(!frontier.empty() and explored.find(current_node) != explored.end()){
				frontier.pop_front();
				current_node = frontier.front();
			}
		}
	}

	if(SolutionFound){ 
		miPlan = current_node.secuencia;
	}

	return miPlan;
}

int CalcularCoste(const stateN2 &current_node, Action action, const vector<vector<unsigned char>> &mapa) {
	
	char cur_char = mapa[current_node.jugador.f][current_node.jugador.c];
	switch(action)
	{
		case actFORWARD:
			if(cur_char == 'A' and !current_node.lleva_bikini) return 100;
			else if(cur_char == 'A' and current_node.lleva_bikini) return 10;
			else if(cur_char == 'B' and !current_node.lleva_zapas) return 50;
			else if(cur_char == 'B' and current_node.lleva_zapas) return 15;
			else if(cur_char == 'T') return 2;
			else return 1;
		break;
		case actTURN_L:
			if(cur_char == 'A' and !current_node.lleva_bikini) return 25;
			else if(cur_char == 'A' and current_node.lleva_bikini) return 5;
			else if(cur_char == 'B' and !current_node.lleva_zapas) return 5;
			else if(cur_char == 'B' and current_node.lleva_zapas) return 1;
			else if(cur_char == 'T') return 2;
			else return 1;
		break;
		case actTURN_R:
			if(cur_char == 'A' and !current_node.lleva_bikini) return 25;
			else if(cur_char == 'A' and current_node.lleva_bikini) return 5;
			else if(cur_char == 'B' and !current_node.lleva_zapas) return 5;
			else if(cur_char == 'B' and current_node.lleva_zapas) return 1;
			else if(cur_char == 'T') return 2;
			else return 1;
		break;
		case actIDLE:
			return 0;
		break;
	}
	return 0;
}

int CalcularCoste(const stateN3 &current_node, Action action, const vector<vector<unsigned char>> &mapa) {
	
	char cur_char = mapa[current_node.jugador.f][current_node.jugador.c];
	char cur_son = mapa[current_node.sonambulo.f][current_node.sonambulo.c];
	switch(action)
	{
		case actFORWARD:
			if(cur_char == 'A' and !current_node.lleva_bikini) return 100;
			else if(cur_char == 'A' and current_node.lleva_bikini) return 10;
			else if(cur_char == 'B' and !current_node.lleva_zapas) return 50;
			else if(cur_char == 'B' and current_node.lleva_zapas) return 15;
			else if(cur_char == 'T') return 2;
			else return 1;
		break;
		case actTURN_L:
			if(cur_char == 'A' and !current_node.lleva_bikini) return 25;
			else if(cur_char == 'A' and current_node.lleva_bikini) return 5;
			else if(cur_char == 'B' and !current_node.lleva_zapas) return 5;
			else if(cur_char == 'B' and current_node.lleva_zapas) return 1;
			else if(cur_char == 'T') return 2;
			else return 1;
		break;
		case actTURN_R:
			if(cur_char == 'A' and !current_node.lleva_bikini) return 25;
			else if(cur_char == 'A' and current_node.lleva_bikini) return 5;
			else if(cur_char == 'B' and !current_node.lleva_zapas) return 5;
			else if(cur_char == 'B' and current_node.lleva_zapas) return 1;
			else if(cur_char == 'T') return 2;
			else return 1;
		break;
		case actSON_FORWARD:
			if(cur_son == 'A' and !current_node.son_lleva_bikini) return 100;
			else if(cur_son == 'A' and current_node.son_lleva_bikini) return 10;
			else if(cur_son == 'B' and !current_node.son_lleva_zapas) return 50;
			else if(cur_son == 'B' and current_node.son_lleva_zapas) return 15;
			else if(cur_son == 'T') return 2;
			else return 1;
		break;
		case actSON_TURN_SR:
			if(cur_son == 'A' and !current_node.son_lleva_bikini) return 7;
			else if(cur_son == 'A' and current_node.son_lleva_bikini) return 2;
			else if(cur_son == 'B' and !current_node.son_lleva_zapas) return 3;
			else if(cur_son == 'B' and current_node.son_lleva_zapas) return 1;
			else if(cur_son == 'T') return 1;
			else return 1;
		break;
		case actSON_TURN_SL:
			if(cur_son == 'A' and !current_node.son_lleva_bikini) return 7;
			else if(cur_son == 'A' and current_node.son_lleva_bikini) return 2;
			else if(cur_son == 'B' and !current_node.son_lleva_zapas) return 3;
			else if(cur_son == 'B' and current_node.son_lleva_zapas) return 1;
			else if(cur_son == 'T') return 1;
			else return 1;
		break;
		case actIDLE:
			return 0;
		break;
	}
	return 0;
}

int HeuristicaMaximo(ubicacion sonambulo, ubicacion objetivo) 
{
	return max(abs(sonambulo.f-objetivo.f),abs(sonambulo.c-objetivo.c));
}

int HeuristicaManhattan(ubicacion sonambulo, ubicacion objetivo) 
{
	return abs(sonambulo.f-objetivo.f) + abs(sonambulo.c-objetivo.c);
}

list<Action> CosteUniforme(const stateN2 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa)
{
	nodeN2 current_node;
	current_node.st = apply(actIDLE,inicio,mapa);
	current_node.coste = 0;
	bool solutionFound = current_node.st.jugador.f == final.f and current_node.st.jugador.c == final.c;
	priority_queue<nodeN2,vector<nodeN2>,greater<nodeN2>> abiertos;
	set<stateN2> cerrados;
	abiertos.push(current_node);

	while(!abiertos.empty() and !solutionFound)
	{
		abiertos.pop();
		cerrados.insert(current_node.st);

		nodeN2 child_forward = current_node;
		child_forward.st = apply(actFORWARD,current_node.st,mapa);
		if (cerrados.find(child_forward.st) == cerrados.end() ) {
			child_forward.secuencia.push_back(actFORWARD);
			child_forward.coste += CalcularCoste(current_node.st,actFORWARD,mapa);
			abiertos.push(child_forward);
		}

		nodeN2 child_left = current_node;
		child_left.st = apply(actTURN_L,current_node.st,mapa);
		if(cerrados.find(child_left.st) == cerrados.end()) {
			child_left.secuencia.push_back(actTURN_L);
			child_left.coste += CalcularCoste(current_node.st,actTURN_L,mapa);
			abiertos.push(child_left);
		}

		nodeN2 child_right = current_node;
		child_right.st = apply(actTURN_R,current_node.st,mapa);
		if(cerrados.find(child_right.st) == cerrados.end()) {
			child_right.secuencia.push_back(actTURN_R);
			child_right.coste += CalcularCoste(current_node.st,actTURN_R,mapa);
			abiertos.push(child_right);
		}


		if(!abiertos.empty()) {
			current_node = abiertos.top();
			while(!abiertos.empty() and cerrados.find(current_node.st) != cerrados.end()) {
				abiertos.pop();
				current_node = abiertos.top();
			}
		}

		solutionFound = current_node.st.jugador.f == final.f and current_node.st.jugador.c == final.c;
	}
	return current_node.secuencia;
}

list<Action> AEstrella(const stateN3 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa) 
{
	nodeN3 current_node;
	current_node.st = apply(actIDLE,inicio,mapa);
	current_node.costeReal = 0;
	current_node.costeHeur = HeuristicaMaximo(current_node.st.sonambulo,final);
	bool solutionFound = current_node.st.sonambulo.f == final.f and current_node.st.sonambulo.c == final.c;
	priority_queue<nodeN3,vector<nodeN3>,greater<nodeN3>> abiertos;
	set<stateN3> cerrados;
	abiertos.push(current_node);

	while(!abiertos.empty() and !solutionFound)
	{
		abiertos.pop();
		cerrados.insert(current_node.st);

		nodeN3 child_forward = current_node;
		child_forward.st = apply(actFORWARD,current_node.st,mapa);
		if (cerrados.find(child_forward.st) == cerrados.end() and !(child_forward.st == current_node.st)) {
			child_forward.secuencia.push_back(actFORWARD);
			child_forward.costeReal = current_node.costeReal + CalcularCoste(current_node.st,actFORWARD,mapa);
			child_forward.costeHeur = HeuristicaMaximo(child_forward.st.sonambulo,final);
			abiertos.push(child_forward);
		}

		nodeN3 child_son_forward = current_node;
		child_son_forward.st = apply(actSON_FORWARD,current_node.st,mapa);
		if (cerrados.find(child_son_forward.st) == cerrados.end() and !(child_son_forward.st == current_node.st)) {
			child_son_forward.secuencia.push_back(actSON_FORWARD);
			child_son_forward.costeReal = current_node.costeReal + CalcularCoste(current_node.st,actSON_FORWARD,mapa);
			child_son_forward.costeHeur = HeuristicaMaximo(child_son_forward.st.sonambulo,final);
			abiertos.push(child_son_forward);
		}

		nodeN3 child_left = current_node;
		child_left.st = apply(actTURN_L,current_node.st,mapa);
		if(cerrados.find(child_left.st) == cerrados.end() and !(child_left.st == current_node.st)) {
			child_left.secuencia.push_back(actTURN_L);
			child_left.costeReal = current_node.costeReal + CalcularCoste(current_node.st,actTURN_L,mapa);
			child_left.costeHeur = HeuristicaMaximo(child_left.st.sonambulo,final);
			abiertos.push(child_left);
		}

		nodeN3 child_son_left = current_node;
		child_son_left.st = apply(actSON_TURN_SL,current_node.st,mapa);
		if(cerrados.find(child_son_left.st) == cerrados.end() and !(child_son_left.st == current_node.st)) {
			child_son_left.secuencia.push_back(actSON_TURN_SL);
			child_son_left.costeReal = current_node.costeReal + CalcularCoste(current_node.st,actSON_TURN_SL,mapa);
			child_son_left.costeHeur = HeuristicaMaximo(child_son_left.st.sonambulo,final);
			abiertos.push(child_son_left);
		}

		nodeN3 child_right = current_node;
		child_right.st = apply(actTURN_R,current_node.st,mapa);
		if(cerrados.find(child_right.st) == cerrados.end() and !(child_right.st == current_node.st)) {
			child_right.secuencia.push_back(actTURN_R);
			child_right.costeReal = current_node.costeReal + CalcularCoste(current_node.st,actTURN_R,mapa);
			child_right.costeHeur = HeuristicaMaximo(child_right.st.sonambulo,final);
			abiertos.push(child_right);
		}

		nodeN3 child_son_right = current_node;
		child_son_right.st = apply(actSON_TURN_SR,current_node.st,mapa);
		if(cerrados.find(child_son_right.st) == cerrados.end() and !(child_son_right.st == current_node.st)) {
			child_son_right.secuencia.push_back(actSON_TURN_SR);
			child_son_right.costeReal = current_node.costeReal + CalcularCoste(current_node.st,actSON_TURN_SR,mapa);
			child_son_right.costeHeur = HeuristicaMaximo(child_son_right.st.sonambulo,final);
			abiertos.push(child_son_right);
		}


		if(!abiertos.empty()) {
			current_node = abiertos.top();
			while(!abiertos.empty() and cerrados.find(current_node.st) != cerrados.end()) {
				abiertos.pop();
				current_node = abiertos.top();
			}
		}

		solutionFound = current_node.st.sonambulo.f == final.f and current_node.st.sonambulo.c == final.c;
	}
	return current_node.secuencia;
}

/** pone a cero todos los elementos de una matriz */
void AnularMatriz(vector<vector<unsigned char>> &matriz)
{
  for (int i = 0; i < matriz.size(); i++)
    for (int j = 0; j < matriz[0].size(); j++)
      matriz[i][j] = 0;
}

/** Permite pintar sobre el mapa del simulador el plan partiendo desde el estado st */
void ComportamientoJugador::VisualizaPlan(const stateN0 &st, const list<Action> &plan)
{
  AnularMatriz(mapaConPlan);
  stateN0 cst = st;

  auto it = plan.begin();
  while (it != plan.end()){
    switch (*it){
      case actFORWARD:
        cst.jugador = NextCasilla(cst.jugador);
	  mapaConPlan[cst.jugador.f][cst.jugador.c] = 1;
	  break;
	case actTURN_R:
        cst.jugador.brujula = (Orientacion)((cst.jugador.brujula + 2) % 8);
	  break;
	case actTURN_L:
	  cst.jugador.brujula = (Orientacion)((cst.jugador.brujula + 6) % 8);
	  break;
	case actSON_FORWARD:
	  cst.sonambulo = NextCasilla(cst.sonambulo);
	  mapaConPlan[cst.sonambulo.f][cst.sonambulo.c] = 2;
	  break;
	case actSON_TURN_SR:
	  cst.sonambulo.brujula = (Orientacion)((cst.sonambulo.brujula + 1) % 8);
	  break;
	case actSON_TURN_SL:
	  cst.sonambulo.brujula = (Orientacion)((cst.sonambulo.brujula + 7) % 8);
	  break;
    }
    it++;
  }
}

int ComportamientoJugador::interact(Action accion, int valor)
{
	return false;
}

/*
	NIVEL 4:
		- Les doy un coste a las interrogaciones tambien (coste 1 y subes el coste del resto, por lo menos al principio) y que haga el AEstrella con eso
		- Empiezo a seguir mi camino hasta encontrar algo que no me merece la pena meterme y vuelvo a hacer el AEstrella con los nuevos datos
		- Recargar siendo la casilla de recarga el objetivo del AEstrella y con los costes normales para el mas optimo MUY IMP
		- Modificar el coste de las casillas o subir la heurística
		- Esperar a que el aldeano se mueva
		- Lobos: el empujon activa el sensor de colision pero puede ser efectivo o no. Puedo ver en cada casilla lo que veria y si veo ahora algo direrente a lo de antes. Y si
			hay dos en los que ves lomismo ya sí que llamas al whereis MUY IMP
		- El jugador 1 punto y sonambulo 10 cada vez que llegan al objetivo. ALGORITMO NIVEL 3 NO VA A FUNCIONAR 
			1. plan de busqueda al sonambulo solo para verlo (cambiando la condicion de parada) y ver lo que tiene delante el sonambulo para que no se choque
			2. llevar el sonambulo al objetivo
					o 
			1. Algoritmo de nivel 3 con mucha heuristica  

*/

int HeuristicaNivel4(stateN3 st, ubicacion objetivo) 
{
	return 10*HeuristicaMaximo(st.sonambulo,objetivo) + HeuristicaManhattan(st.jugador,objetivo);
}

bool UbicacionesCercanas(ubicacion ubi1, ubicacion ubi2) {
	return max(abs(ubi1.f-ubi2.f),abs(ubi1.c-ubi2.c)) <= 3;
}

list<Action> AlgoritmoNivel4MapaDesconocido(const stateN3 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa) 
{
	nodeN3 current_node;
	current_node.st = applyNivel4(actIDLE,inicio,mapa);
	current_node.costeReal = 0;
	current_node.costeHeur = HeuristicaNivel4(current_node.st,final);
	bool solutionFound = current_node.st.sonambulo.f == final.f and current_node.st.sonambulo.c == final.c;
	priority_queue<nodeN3,vector<nodeN3>,greater<nodeN3>> abiertos;
	set<stateN3> cerrados;
	abiertos.push(current_node);
	priority_queue<nodeN3, vector<nodeN3>,greater<nodeN3>> soluciones;

	while(!abiertos.empty() and !solutionFound)
	{
		abiertos.pop();
		cerrados.insert(current_node.st);

		nodeN3 child_forward = current_node;
		child_forward.st = applyNivel4(actFORWARD,current_node.st,mapa);
		if (cerrados.find(child_forward.st) == cerrados.end() and !(child_forward.st == current_node.st) and !(child_forward.st.jugador.f == final.f && child_forward.st.jugador.c == final.c)) {
			child_forward.secuencia.push_back(actFORWARD);
			child_forward.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actFORWARD,mapa);
			child_forward.costeHeur = HeuristicaNivel4(child_forward.st,final);
			abiertos.push(child_forward);
		}

		nodeN3 child_son_forward = current_node;
		child_son_forward.st = applyNivel4(actSON_FORWARD,current_node.st,mapa);
		if (cerrados.find(child_son_forward.st) == cerrados.end() and !(child_son_forward.st == current_node.st)) {
			child_son_forward.secuencia.push_back(actSON_FORWARD);
			child_son_forward.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actSON_FORWARD,mapa);
			child_son_forward.costeHeur = HeuristicaNivel4(child_son_forward.st,final);
			abiertos.push(child_son_forward);
			if(child_son_forward.st.sonambulo.f == final.f and child_son_forward.st.sonambulo.c == final.c) {
				soluciones.push(child_son_forward);
			}
		}

		nodeN3 child_left = current_node;
		child_left.st = applyNivel4(actTURN_L,current_node.st,mapa);
		if(cerrados.find(child_left.st) == cerrados.end() and !(child_left.st == current_node.st)) {
			child_left.secuencia.push_back(actTURN_L);
			child_left.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actTURN_L,mapa);
			child_left.costeHeur = HeuristicaNivel4(child_left.st,final);
			abiertos.push(child_left);
		}

		nodeN3 child_son_left = current_node;
		child_son_left.st = applyNivel4(actSON_TURN_SL,current_node.st,mapa);
		if(cerrados.find(child_son_left.st) == cerrados.end() and !(child_son_left.st == current_node.st)) {
			child_son_left.secuencia.push_back(actSON_TURN_SL);
			child_son_left.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actSON_TURN_SL,mapa);
			child_son_left.costeHeur = HeuristicaNivel4(child_son_left.st,final);
			abiertos.push(child_son_left);
		}

		nodeN3 child_right = current_node;
		child_right.st = applyNivel4(actTURN_R,current_node.st,mapa);
		if(cerrados.find(child_right.st) == cerrados.end() and !(child_right.st == current_node.st)) {
			child_right.secuencia.push_back(actTURN_R);
			child_right.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actTURN_R,mapa);
			child_right.costeHeur = HeuristicaNivel4(child_right.st,final);
			abiertos.push(child_right);
		}

		nodeN3 child_son_right = current_node;
		child_son_right.st = applyNivel4(actSON_TURN_SR,current_node.st,mapa);
		if(cerrados.find(child_son_right.st) == cerrados.end() and !(child_son_right.st == current_node.st)) {
			child_son_right.secuencia.push_back(actSON_TURN_SR);
			child_son_right.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actSON_TURN_SR,mapa);
			child_son_right.costeHeur = HeuristicaNivel4(child_son_right.st,final);;
			abiertos.push(child_son_right);
		}


		if(!abiertos.empty()) {
			current_node = abiertos.top();
			while(!abiertos.empty() and cerrados.find(current_node.st) != cerrados.end()) {
				abiertos.pop();
				if(!abiertos.empty())
					current_node = abiertos.top();
			}
		}

		solutionFound = current_node.st.sonambulo.f == final.f and current_node.st.sonambulo.c == final.c;

		if(cerrados.size() >= 150000) {
			if(!soluciones.empty()) {
				current_node = soluciones.top();
				solutionFound = true;
			} else {
				break;
			}
		}
		if(cerrados.size()%50000==0) {
			cout << "Numero nodos " << cerrados.size() << endl;
		}
	}
	
	if(solutionFound) return current_node.secuencia;
	else return {};
}

list<Action> BusquedaObjetivo(const stateN3 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa) 
{
	nodeN3 current_node;
	current_node.st = applyBusquedaSonam(actIDLE,inicio,mapa);
	current_node.costeReal = 0;
	current_node.costeHeur = HeuristicaManhattan(current_node.st.jugador,final);
	bool solutionFound = current_node.st.jugador.f == final.f and current_node.st.jugador.c == final.c;
	priority_queue<nodeN3,vector<nodeN3>,greater<nodeN3>> abiertos;
	set<stateN3> cerrados;
	priority_queue<nodeN3,vector<nodeN3>,greater<nodeN3>> soluciones;
	abiertos.push(current_node);

	while(!abiertos.empty() and !solutionFound)
	{
		abiertos.pop();
		cerrados.insert(current_node.st);

		nodeN3 child_forward = current_node;
		child_forward.st = applyBusquedaSonam(actFORWARD,current_node.st,mapa);
		if (cerrados.find(child_forward.st) == cerrados.end() and !(child_forward.st == current_node.st)) {
			child_forward.secuencia.push_back(actFORWARD);
			child_forward.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actFORWARD,mapa);
			child_forward.costeHeur =HeuristicaManhattan(child_forward.st.jugador,final);
			abiertos.push(child_forward);
			if( child_forward.st.jugador.f == final.f and child_forward.st.jugador.c == final.c) {
				soluciones.push(child_forward);
			}
		}

		nodeN3 child_left = current_node;
		child_left.st = applyBusquedaSonam(actTURN_L,current_node.st,mapa);
		if(cerrados.find(child_left.st) == cerrados.end() and !(child_left.st == current_node.st)) {
			child_left.secuencia.push_back(actTURN_L);
			child_left.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actTURN_L,mapa);
			child_left.costeHeur = HeuristicaManhattan(child_left.st.jugador,final);
			abiertos.push(child_left);
		}

		nodeN3 child_right = current_node;
		child_right.st = applyBusquedaSonam(actTURN_R,current_node.st,mapa);
		if(cerrados.find(child_right.st) == cerrados.end() and !(child_right.st == current_node.st)) {
			child_right.secuencia.push_back(actTURN_R);
			child_right.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actTURN_R,mapa);
			child_right.costeHeur = HeuristicaManhattan(child_right.st.jugador,final);
			abiertos.push(child_right);
		}


		if(!abiertos.empty()) {
			current_node = abiertos.top();
			while(!abiertos.empty() and cerrados.find(current_node.st) != cerrados.end()) {
				abiertos.pop();
				if(!abiertos.empty())
					current_node = abiertos.top();
			}
		}

		solutionFound =  current_node.st.jugador.f == final.f and current_node.st.jugador.c == final.c;

		if(cerrados.size() >= 1000000) {
			if(!soluciones.empty()) {
				current_node = soluciones.top();
				solutionFound = true;
			} else {
				break;
			}
		}
	}
	
	if(solutionFound) return current_node.secuencia;
	else return {};
}

list<Action> BusquedaSonambulo(const stateN3 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa, stateN3 &finalJugador) 
{
	nodeN3 current_node;
	current_node.st = applyBusquedaSonam(actIDLE,inicio,mapa);
	current_node.costeReal = 0;
	current_node.costeHeur = HeuristicaMaximo(current_node.st.sonambulo,final);
	bool solutionFound = JugadorVeDelanteSonambulo(current_node.st,mapa) && JugadorVeSonambulo(current_node.st,mapa);
	priority_queue<nodeN3,vector<nodeN3>,greater<nodeN3>> abiertos;
	set<stateN3> cerrados;
	priority_queue<nodeN3,vector<nodeN3>,greater<nodeN3>> soluciones;
	abiertos.push(current_node);

	while(!abiertos.empty() and !solutionFound)
	{
		abiertos.pop();
		cerrados.insert(current_node.st);

		nodeN3 child_forward = current_node;
		child_forward.st = applyBusquedaSonam(actFORWARD,current_node.st,mapa);
		if (cerrados.find(child_forward.st) == cerrados.end() and !(child_forward.st == current_node.st)) {
			child_forward.secuencia.push_back(actFORWARD);
			child_forward.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actFORWARD,mapa);
			child_forward.costeHeur = HeuristicaMaximo(child_forward.st.sonambulo,child_forward.st.jugador);
			abiertos.push(child_forward);
			if(JugadorVeDelanteSonambulo(current_node.st,mapa) && JugadorVeSonambulo(current_node.st,mapa)) {
				soluciones.push(child_forward);
			}
		}

		nodeN3 child_left = current_node;
		child_left.st = applyBusquedaSonam(actTURN_L,current_node.st,mapa);
		if(cerrados.find(child_left.st) == cerrados.end() and !(child_left.st == current_node.st)) {
			child_left.secuencia.push_back(actTURN_L);
			child_left.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actTURN_L,mapa);
			child_left.costeHeur = HeuristicaMaximo(child_left.st.sonambulo,child_left.st.jugador);
			abiertos.push(child_left);
		}

		nodeN3 child_right = current_node;
		child_right.st = applyBusquedaSonam(actTURN_R,current_node.st,mapa);
		if(cerrados.find(child_right.st) == cerrados.end() and !(child_right.st == current_node.st)) {
			child_right.secuencia.push_back(actTURN_R);
			child_right.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actTURN_R,mapa);
			child_right.costeHeur = HeuristicaMaximo(child_right.st.sonambulo,child_right.st.jugador);
			abiertos.push(child_right);
		}

		if(!abiertos.empty()) {
			current_node = abiertos.top();
			while(!abiertos.empty() and cerrados.find(current_node.st) != cerrados.end()) {
				abiertos.pop();
				if(!abiertos.empty())
					current_node = abiertos.top();
			}
		}

		solutionFound = JugadorVeDelanteSonambulo(current_node.st,mapa) && JugadorVeSonambulo(current_node.st,mapa);

		if(cerrados.size() >= 1000000) {
			if(!soluciones.empty()) {
				current_node = soluciones.top();
				solutionFound = true;
			} else {
				break;
			}
		}
	}
	if(solutionFound) {
		finalJugador.jugador = current_node.st.jugador;
		finalJugador.sonambulo = current_node.st.sonambulo;
		return current_node.secuencia;
	}
	else return {};
}

list<Action> BusquedaRecarga(const stateN3 &inicio, const vector<vector<unsigned char>> &mapa) 
{
	nodeN3 current_node;
	current_node.st = applyBusquedaSonam(actIDLE,inicio,mapa);
	current_node.costeReal = 0;
	current_node.costeHeur = 0;
	bool solutionFound =  mapa[current_node.st.jugador.f][current_node.st.jugador.c] == 'X';
	priority_queue<nodeN3,vector<nodeN3>,greater<nodeN3>> abiertos;
	set<stateN3> cerrados;
	abiertos.push(current_node);

	while(!abiertos.empty() and !solutionFound)
	{
		abiertos.pop();
		cerrados.insert(current_node.st);

		nodeN3 child_forward = current_node;
		child_forward.st = applyBusquedaSonam(actFORWARD,current_node.st,mapa);
		if (cerrados.find(child_forward.st) == cerrados.end() and !(child_forward.st == current_node.st)) {
			child_forward.secuencia.push_back(actFORWARD);
			child_forward.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actFORWARD,mapa);
			child_forward.costeHeur = 0;
			abiertos.push(child_forward);
		}

		nodeN3 child_left = current_node;
		child_left.st = applyBusquedaSonam(actTURN_L,current_node.st,mapa);
		if(cerrados.find(child_left.st) == cerrados.end() and !(child_left.st == current_node.st)) {
			child_left.secuencia.push_back(actTURN_L);
			child_left.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actTURN_L,mapa);
			child_left.costeHeur = 0;
			abiertos.push(child_left);
		}

		nodeN3 child_right = current_node;
		child_right.st = applyBusquedaSonam(actTURN_R,current_node.st,mapa);
		if(cerrados.find(child_right.st) == cerrados.end() and !(child_right.st == current_node.st)) {
			child_right.secuencia.push_back(actTURN_R);
			child_right.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actTURN_R,mapa);
			child_right.costeHeur = 0;
			abiertos.push(child_right);
		}

		if(!abiertos.empty()) {
			current_node = abiertos.top();
			while(!abiertos.empty() and cerrados.find(current_node.st) != cerrados.end()) {
				abiertos.pop();
				if(!abiertos.empty())
					current_node = abiertos.top();
			}
		}

		solutionFound = mapa[current_node.st.jugador.f][current_node.st.jugador.c] == 'X';
	}
	if(solutionFound) return current_node.secuencia;
	else return {};
}

int CosteNivel4(const stateN3 &current_node, Action action, const vector<vector<unsigned char>> &mapa) {
	//return 0;
	char cur_char = mapa[current_node.jugador.f][current_node.jugador.c];
	char cur_son = mapa[current_node.sonambulo.f][current_node.sonambulo.c];
	switch(action)
	{
		case actFORWARD:
			if(cur_char == 'A' and !current_node.lleva_bikini) return 200;
			else if(cur_char == 'A' and current_node.lleva_bikini) return 20;
			else if(cur_char == 'B' and !current_node.lleva_zapas) return 100;
			else if(cur_char == 'B' and current_node.lleva_zapas) return 30;
			else if(cur_char == 'T') return 4;
			else if(cur_char == '?') return 2;
			else return 1;
		break;
		case actTURN_L:
			if(cur_char == 'A' and !current_node.lleva_bikini) return 50;
			else if(cur_char == 'A' and current_node.lleva_bikini) return 10;
			else if(cur_char == 'B' and !current_node.lleva_zapas) return 10;
			else if(cur_char == 'B' and current_node.lleva_zapas) return 2;
			else if(cur_char == 'T') return 4;
			else if(cur_char == '?') return 2;
			else return 1;
		break;
		case actTURN_R:
			if(cur_char == 'A' and !current_node.lleva_bikini) return 50;
			else if(cur_char == 'A' and current_node.lleva_bikini) return 510;
			else if(cur_char == 'B' and !current_node.lleva_zapas) return 10;
			else if(cur_char == 'B' and current_node.lleva_zapas) return 2;
			else if(cur_char == 'T') return 4;
			else if(cur_char == '?') return 2;
			else return 1;
		break;
		case actSON_FORWARD:
			if(cur_son == 'A' and !current_node.son_lleva_bikini) return 200;
			else if(cur_son == 'A' and current_node.son_lleva_bikini) return 20;
			else if(cur_son == 'B' and !current_node.son_lleva_zapas) return 100;
			else if(cur_son == 'B' and current_node.son_lleva_zapas) return 30;
			else if(cur_son == 'T') return 4;
			else if(cur_son == '?') return 2;
			else return 1;
		break;
		case actSON_TURN_SR:
			if(cur_son == 'A' and !current_node.son_lleva_bikini) return 14;
			else if(cur_son == 'A' and current_node.son_lleva_bikini) return 4;
			else if(cur_son == 'B' and !current_node.son_lleva_zapas) return 6;
			else if(cur_son == 'B' and current_node.son_lleva_zapas) return 2;
			else if(cur_son == 'T') return 2;
			else if(cur_son == '?') return 2;
			else return 1;
		break;
		case actSON_TURN_SL:
			if(cur_son == 'A' and !current_node.son_lleva_bikini) return 14;
			else if(cur_son == 'A' and current_node.son_lleva_bikini) return 4;
			else if(cur_son == 'B' and !current_node.son_lleva_zapas) return 6;
			else if(cur_son == 'B' and current_node.son_lleva_zapas) return 2;
			else if(cur_son == 'T') return 2;
			else if(cur_son == '?') return 2;
			else return 1;
		break;
		case actIDLE:
			return 0;
		break;
	}
	return 0;
}

bool AlguienDelanteSonambulo(const stateN3 &st,Sensores sensores) {
	Orientacion oriJug = st.jugador.brujula;
	Orientacion oriSon;
	switch(oriJug) {
		case 0: oriSon = st.sonambulo.brujula; break;
		case 2: oriSon = static_cast<Orientacion>((st.sonambulo.brujula + 6) % 8); break;
		case 4: oriSon = static_cast<Orientacion>((st.sonambulo.brujula + 4) % 8); break;
		case 6: oriSon = static_cast<Orientacion>((st.sonambulo.brujula + 2) % 8); break;
	}
	int posDelanteSon;
	int posSon = 0;
	for(int i = 1; i < 16 && posSon == 0; i++) {
		if(sensores.superficie[i] == 's') posSon = i;
	}
	switch(oriSon) {
		case 0:
			if(posSon >= 1 && posSon <= 3) posDelanteSon = posSon + 4;
			else if(posSon >= 4 && posSon <= 8) posDelanteSon = posSon + 6;
			else posDelanteSon = -1;
		break;
		case 1:
			if(posSon >= 1 && posSon <= 3) posDelanteSon = posSon + 5;
			else if(posSon >= 4 && posSon <= 8) posDelanteSon = posSon + 7;
			else posDelanteSon = -1;
		break;
		case 2:
			if(posSon != 3 and posSon != 8 and posSon != 15) posDelanteSon = posSon + 1;
			else posDelanteSon = -1;
		break;
		case 3:
			if(posSon >= 4 && posSon <= 6) posDelanteSon = posSon - 3;
			else if(posSon >= 9 && posSon <= 13) posDelanteSon = posSon - 5;
			else if(posSon == 1) posDelanteSon = 0;
			else posDelanteSon = -1; 
		break;
		case 4:
			if(posSon >= 5 && posSon <= 7) posDelanteSon = posSon - 4;
			else if(posSon >= 10 && posSon <= 14) posDelanteSon = posSon - 6;
			else if(posSon == 2) posDelanteSon = 0;
			else posDelanteSon = -1;
		break;
		case 5:
			if(posSon >= 11 && posSon <= 15) posDelanteSon = posSon - 7;
			else if(posSon >= 6 && posSon <= 8) posDelanteSon = posSon - 5;
			else if(posSon == 3) posDelanteSon = 0;
			else posDelanteSon = -1;
		break;
		case 6: 
			if(posSon == 2 || posSon == 3 || (posSon >=5 and posSon <= 8) || (posSon >= 10 and posSon <= 15)) posDelanteSon = posSon - 1;
			else posDelanteSon = -1;
		break;
		case 7:
			if(posSon >= 1 and posSon <= 3) posDelanteSon = posSon + 3;
			else if(posSon >= 4 and posSon <= 8) posDelanteSon = posSon + 5;
			else posDelanteSon = -1;
		break;
	}
	return !(posDelanteSon != -1 && sensores.superficie[posDelanteSon] == '_');
}

stateN3 applyObjetivoSonam(const Action &a, const stateN3 &st, const vector<vector<unsigned char>> &mapa)
{
 	stateN3 st_result = st;
	ubicacion sig_ubicacion;
	switch (a){
		case actSON_FORWARD:
			sig_ubicacion = NextCasilla(st.sonambulo);
			if(CasillaTransitable(sig_ubicacion, mapa)) {
				st_result.sonambulo = sig_ubicacion;
				if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'D') {
					st_result.son_lleva_zapas = true;
					st_result.son_lleva_bikini = false;
				} else if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'K') {
					st_result.son_lleva_zapas = false;
					st_result.son_lleva_bikini = true;
				}
			}
			break;
		case actSON_TURN_SL:
			st_result.sonambulo.brujula = static_cast<Orientacion>((st_result.sonambulo.brujula + 7) % 8);
			break;
		case actSON_TURN_SR:
			st_result.sonambulo.brujula = static_cast<Orientacion>((st_result.sonambulo.brujula + 1) % 8);
			break;
	}
	return st_result; 
}

list<Action> BusquedaObjetivoSonam(const stateN3 &inicio, const ubicacion &final, const vector<vector<unsigned char>> &mapa) 
{
	nodeN3 current_node;
	current_node.st = applyObjetivoSonam(actIDLE,inicio,mapa);
	current_node.costeReal = 0;
	current_node.costeHeur = HeuristicaNivel4(current_node.st,final);
	bool solutionFound = current_node.st.sonambulo.f == final.f and current_node.st.sonambulo.c == final.c;
	priority_queue<nodeN3,vector<nodeN3>,greater<nodeN3>> abiertos;
	set<stateN3> cerrados;
	abiertos.push(current_node);
	priority_queue<nodeN3, vector<nodeN3>,greater<nodeN3>> soluciones;

	while(!abiertos.empty() and !solutionFound)
	{
		abiertos.pop();
		cerrados.insert(current_node.st);

		nodeN3 child_son_forward = current_node;
		child_son_forward.st = applyObjetivoSonam(actSON_FORWARD,current_node.st,mapa);
		if (cerrados.find(child_son_forward.st) == cerrados.end() and !(child_son_forward.st == current_node.st)) {
			child_son_forward.secuencia.push_back(actSON_FORWARD);
			child_son_forward.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actSON_FORWARD,mapa);
			child_son_forward.costeHeur = HeuristicaNivel4(child_son_forward.st,final);
			abiertos.push(child_son_forward);
			if(child_son_forward.st.sonambulo.f == final.f and child_son_forward.st.sonambulo.c == final.c) {
				soluciones.push(child_son_forward);
			}
		}

		nodeN3 child_son_left = current_node;
		child_son_left.st = applyObjetivoSonam(actSON_TURN_SL,current_node.st,mapa);
		if(cerrados.find(child_son_left.st) == cerrados.end() and !(child_son_left.st == current_node.st)) {
			child_son_left.secuencia.push_back(actSON_TURN_SL);
			child_son_left.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actSON_TURN_SL,mapa);
			child_son_left.costeHeur = HeuristicaNivel4(child_son_left.st,final);
			abiertos.push(child_son_left);
		}

		nodeN3 child_son_right = current_node;
		child_son_right.st = applyObjetivoSonam(actSON_TURN_SR,current_node.st,mapa);
		if(cerrados.find(child_son_right.st) == cerrados.end() and !(child_son_right.st == current_node.st)) {
			child_son_right.secuencia.push_back(actSON_TURN_SR);
			child_son_right.costeReal = current_node.costeReal + CosteNivel4(current_node.st,actSON_TURN_SR,mapa);
			child_son_right.costeHeur = HeuristicaNivel4(child_son_right.st,final);;
			abiertos.push(child_son_right);
		}


		if(!abiertos.empty()) {
			current_node = abiertos.top();
			while(!abiertos.empty() and cerrados.find(current_node.st) != cerrados.end()) {
				abiertos.pop();
				if(!abiertos.empty())
					current_node = abiertos.top();
			}
		}

		solutionFound = !soluciones.empty();
	}
	
	if(solutionFound) return soluciones.top().secuencia;
	else return {};
}

stateN3 applyNivel4(const Action &a, const stateN3 &st, const vector<vector<unsigned char>> &mapa)
{
 	stateN3 st_result = st;
	ubicacion sig_ubicacion;
	switch (a){
		case actIDLE:
			if(mapa[st.jugador.f][st.jugador.c] == 'D') {
				st_result.lleva_zapas = true;
				st_result.lleva_bikini = false;
			} else if(mapa[st.jugador.f][st.jugador.c] == 'K') {
				st_result.lleva_zapas = false;
				st_result.lleva_bikini = true;
			}
			if(mapa[st.sonambulo.f][st.sonambulo.c] == 'D') {
				st_result.son_lleva_zapas = true;
				st_result.son_lleva_bikini = false;
			} else if(mapa[st.sonambulo.f][st.sonambulo.c] == 'K') {
				st_result.son_lleva_zapas = false;
				st_result.son_lleva_bikini = true;
			}
			break;
		case actFORWARD: // si casilla delante es transitable y no está ocupada por el sonámbulo
			sig_ubicacion = NextCasilla(st.jugador);
			if (CasillaTransitable(sig_ubicacion, mapa) and !(sig_ubicacion.f == st.sonambulo.f and sig_ubicacion.c == st.sonambulo.c) and (JugadorVeSonambulo(st,mapa) or UbicacionesCercanas(st.jugador,st.sonambulo))){
				st_result.jugador = sig_ubicacion;
				if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'D') {
					st_result.lleva_zapas = true;
					st_result.lleva_bikini = false;
				} else if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'K') {
					st_result.lleva_zapas = false;
					st_result.lleva_bikini = true;
				}
			}
			break;
		case actTURN_L:
			if( (JugadorVeSonambulo(st,mapa) or UbicacionesCercanas(st.jugador,st.sonambulo)))
				st_result.jugador.brujula = static_cast<Orientacion>((st_result.jugador.brujula + 6) % 8);
			break;

		case actTURN_R:
			if((JugadorVeSonambulo(st,mapa) or UbicacionesCercanas(st.jugador,st.sonambulo)))
				st_result.jugador.brujula = static_cast<Orientacion>((st_result.jugador.brujula + 2) % 8);
			break;
		case actSON_FORWARD:
			sig_ubicacion = NextCasilla(st.sonambulo);
			if(CasillaTransitable(sig_ubicacion, mapa) and JugadorVeDelanteSonambulo(st, mapa) and JugadorVeSonambulo(st,mapa) and !(sig_ubicacion.f == st.jugador.f and sig_ubicacion.c == st.jugador.c)) {
				st_result.sonambulo = sig_ubicacion;
				if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'D') {
					st_result.son_lleva_zapas = true;
					st_result.son_lleva_bikini = false;
				} else if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'K') {
					st_result.son_lleva_zapas = false;
					st_result.son_lleva_bikini = true;
				}
			}
			break;
		case actSON_TURN_SL:
			if(JugadorVeDelanteSonambulo(st_result,mapa) && JugadorVeSonambulo(st,mapa)) {
				st_result.sonambulo.brujula = static_cast<Orientacion>((st_result.sonambulo.brujula + 7) % 8);
			}
			break;
		case actSON_TURN_SR:
			if(JugadorVeDelanteSonambulo(st_result,mapa) && JugadorVeSonambulo(st,mapa)) {
				st_result.sonambulo.brujula = static_cast<Orientacion>((st_result.sonambulo.brujula + 1) % 8);
			}
			break;
	}
	return st_result; 
}

stateN3 applyBusquedaSonam(const Action &a, const stateN3 &st, const vector<vector<unsigned char>> &mapa)
{
 	stateN3 st_result = st;
	ubicacion sig_ubicacion;
	switch (a){
		case actIDLE:
			if(mapa[st.jugador.f][st.jugador.c] == 'D') {
				st_result.lleva_zapas = true;
				st_result.lleva_bikini = false;
			} else if(mapa[st.jugador.f][st.jugador.c] == 'K') {
				st_result.lleva_zapas = false;
				st_result.lleva_bikini = true;
			}
			if(mapa[st.sonambulo.f][st.sonambulo.c] == 'D') {
				st_result.son_lleva_zapas = true;
				st_result.son_lleva_bikini = false;
			} else if(mapa[st.sonambulo.f][st.sonambulo.c] == 'K') {
				st_result.son_lleva_zapas = false;
				st_result.son_lleva_bikini = true;
			}
			break;
		case actFORWARD: // si casilla delante es transitable y no está ocupada por el sonámbulo
			sig_ubicacion = NextCasilla(st.jugador);
			if (CasillaTransitable(sig_ubicacion, mapa) and !(sig_ubicacion.f == st.sonambulo.f and sig_ubicacion.c == st.sonambulo.c)){
				st_result.jugador = sig_ubicacion;
				if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'D') {
					st_result.lleva_zapas = true;
					st_result.lleva_bikini = false;
				} else if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'K') {
					st_result.lleva_zapas = false;
					st_result.lleva_bikini = true;
				}
			}
			break;
		case actTURN_L:
			st_result.jugador.brujula = static_cast<Orientacion>((st_result.jugador.brujula + 6) % 8);
			break;

		case actTURN_R:
			st_result.jugador.brujula = static_cast<Orientacion>((st_result.jugador.brujula + 2) % 8);
			break;
		case actSON_FORWARD:
			sig_ubicacion = NextCasilla(st.sonambulo);
			if(CasillaTransitable(sig_ubicacion, mapa) and JugadorVeDelanteSonambulo(st, mapa) and JugadorVeSonambulo(st,mapa) and !(sig_ubicacion.f == st.jugador.f and sig_ubicacion.c == st.jugador.c)) {
				st_result.sonambulo = sig_ubicacion;
				if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'D') {
					st_result.son_lleva_zapas = true;
					st_result.son_lleva_bikini = false;
				} else if(mapa[sig_ubicacion.f][sig_ubicacion.c] == 'K') {
					st_result.son_lleva_zapas = false;
					st_result.son_lleva_bikini = true;
				}
			}
			break;
		case actSON_TURN_SL:
			if(JugadorVeDelanteSonambulo(st_result,mapa) && JugadorVeSonambulo(st,mapa)) {
				st_result.sonambulo.brujula = static_cast<Orientacion>((st_result.sonambulo.brujula + 7) % 8);
			}
			break;
		case actSON_TURN_SR:
			if(JugadorVeDelanteSonambulo(st_result,mapa) && JugadorVeSonambulo(st,mapa)) {
				st_result.sonambulo.brujula = static_cast<Orientacion>((st_result.sonambulo.brujula + 1) % 8);
			}
			break;
	}
	return st_result; 
}

void ActualizarEstado(Action last_action, stateN3 &current_state, ubicacion &goal, Sensores sensores)
{
	if(sensores.terreno[0] == 'K') {
		current_state.lleva_bikini = true;
		current_state.lleva_zapas = false;
	}else if(sensores.terreno[0] == 'D') {
		current_state.lleva_bikini = false;
		current_state.lleva_zapas = true;
	}

	int posSon = -1;
	for(int i = 1; i < 16 && posSon == -1; i++) {
		if(sensores.superficie[i] == 's') posSon = i;
	}
	if(posSon!=-1) {
		if(sensores.terreno[posSon] == 'K') {
			current_state.son_lleva_bikini = true;
			current_state.son_lleva_zapas = false;
		}else if(sensores.terreno[posSon] == 'D') {
			current_state.son_lleva_bikini = false;
			current_state.son_lleva_zapas = true;
	}
	}

	switch(last_action) {
		case actFORWARD:
			switch (current_state.jugador.brujula){
				case norte: current_state.jugador.f--; break;
				case noreste: current_state.jugador.f--; current_state.jugador.c++; break;
				case este: current_state.jugador.c++; break;
				case sureste: current_state.jugador.f++; current_state.jugador.c++; break;
				case sur: current_state.jugador.f++; break;
				case suroeste: current_state.jugador.f++; current_state.jugador.c--; break;
				case oeste: current_state.jugador.c--; break;
				case noroeste: current_state.jugador.f--; current_state.jugador.c--; break;
			}
			break;
		case actTURN_L:
			current_state.jugador.brujula = static_cast<Orientacion>((current_state.jugador.brujula+6)%8);
			break;
		case actTURN_R:
			current_state.jugador.brujula = static_cast<Orientacion>((current_state.jugador.brujula+2)%8);
			break;
		case actSON_TURN_SL:
			current_state.sonambulo.brujula = static_cast<Orientacion>((current_state.sonambulo.brujula+7)%8);
			break;
		case actSON_TURN_SR:
			current_state.sonambulo.brujula = static_cast<Orientacion>((current_state.sonambulo.brujula+1)%8);
			break;
		case actSON_FORWARD:
			switch(current_state.sonambulo.brujula) {
				case norte: current_state.sonambulo.f--; break;
				case noreste: current_state.sonambulo.f--; current_state.sonambulo.c++; break;
				case este: current_state.sonambulo.c++; break;
				case sureste: current_state.sonambulo.f++; current_state.sonambulo.c++; break;
				case sur: current_state.sonambulo.f++; break;
				case suroeste: current_state.sonambulo.f++; current_state.sonambulo.c--; break;
				case oeste: current_state.sonambulo.c--; break;
				case noroeste: current_state.sonambulo.f--; current_state.sonambulo.c--; break;
			}
			break;
		case actWHEREIS:
			current_state.jugador.f = sensores.posF;
			current_state.jugador.c = sensores.posC;
			current_state.jugador.brujula = sensores.sentido;
			current_state.sonambulo.f = sensores.SONposF;
			current_state.sonambulo.c = sensores.SONposC;
			current_state.sonambulo.brujula = sensores.SONsentido;
			goal.f = sensores.destinoF;
			goal.c = sensores.destinoC;
			break;
	}
}

void PonerTerrenoEnMatriz(const vector<unsigned char> &terreno, const stateN3 &st, vector < vector <unsigned char> > &matriz) {
		ubicacion jugador = st.jugador;												
		matriz[jugador.f][jugador.c] = terreno[0];
		int casilla = 0;
		if(jugador.brujula == norte) {
			matriz[jugador.f-1][jugador.c-1] = terreno[1];
			matriz[jugador.f-1][jugador.c] = terreno[2];
			matriz[jugador.f-1][jugador.c+1] = terreno[3];
			matriz[jugador.f-2][jugador.c-2] = terreno[4];
			matriz[jugador.f-2][jugador.c-1] = terreno[5];
			matriz[jugador.f-2][jugador.c] = terreno[6];
			matriz[jugador.f-2][jugador.c+1] = terreno[7];
			matriz[jugador.f-2][jugador.c+2] = terreno[8];
			matriz[jugador.f-3][jugador.c-3] = terreno[9];
			matriz[jugador.f-3][jugador.c-2] = terreno[10];
			matriz[jugador.f-3][jugador.c-1] = terreno[11];
			matriz[jugador.f-3][jugador.c] = terreno[12];
			matriz[jugador.f-3][jugador.c+1] = terreno[13];
			matriz[jugador.f-3][jugador.c+2] = terreno[14];
			matriz[jugador.f-3][jugador.c+3] = terreno[15];
		} else if(jugador.brujula == sur) {
			for(int fila = 1; fila <= 3; fila++) {
				for(int columna = fila; columna >= -fila; columna--) {
					casilla++;
					matriz[jugador.f + fila][jugador.c + columna] = terreno[casilla];
				}
			}
		} else if(jugador.brujula == este) {
			for(int columna = 1; columna <= 3; columna++) {
				for(int fila = -columna; fila <= columna; fila++) {
					casilla++;
					matriz[jugador.f + fila][jugador.c + columna] = terreno[casilla];
				}
			}
		} else if(jugador.brujula == oeste) {
			for(int columna = -1; columna >= -3; columna--) {
				for(int fila = -columna; fila >= columna; fila--) {
					casilla++;
					matriz[jugador.f + fila][jugador.c + columna] = terreno[casilla];
				}
			}
		} else if(jugador.brujula == noreste) {
			matriz[jugador.f][jugador.c+1] = terreno[3];
			matriz[jugador.f][jugador.c+2] = terreno[8];
			matriz[jugador.f][jugador.c+3] = terreno[15];
			matriz[jugador.f-1][jugador.c] = terreno[1];
			matriz[jugador.f-1][jugador.c+1] = terreno[2];
			matriz[jugador.f-1][jugador.c+2] = terreno[7];
			matriz[jugador.f-1][jugador.c+3] = terreno[14];
			matriz[jugador.f-2][jugador.c] = terreno[4];
			matriz[jugador.f-2][jugador.c+1] = terreno[5];
			matriz[jugador.f-2][jugador.c+2] = terreno[6];
			matriz[jugador.f-2][jugador.c+3] = terreno[13];
			matriz[jugador.f-3][jugador.c] = terreno[9];
			matriz[jugador.f-3][jugador.c+1] = terreno[10];
			matriz[jugador.f-3][jugador.c+2] = terreno[11];
			matriz[jugador.f-3][jugador.c+3] = terreno[12];
		} else if(jugador.brujula == sureste) {
			matriz[jugador.f][jugador.c+1] = terreno[1];
			matriz[jugador.f][jugador.c+2] = terreno[4];
			matriz[jugador.f][jugador.c+3] = terreno[9];
			matriz[jugador.f+1][jugador.c] = terreno[3];
			matriz[jugador.f+1][jugador.c+1] = terreno[2];
			matriz[jugador.f+1][jugador.c+2] = terreno[5];
			matriz[jugador.f+1][jugador.c+3] = terreno[10];
			matriz[jugador.f+2][jugador.c] = terreno[8];
			matriz[jugador.f+2][jugador.c+1] = terreno[7];
			matriz[jugador.f+2][jugador.c+2] = terreno[6];
			matriz[jugador.f+2][jugador.c+3] = terreno[11];
			matriz[jugador.f+3][jugador.c] = terreno[15];
			matriz[jugador.f+3][jugador.c+1] = terreno[14];
			matriz[jugador.f+3][jugador.c+2] = terreno[13];
			matriz[jugador.f+3][jugador.c+3] = terreno[12];
		} else if (jugador.brujula == suroeste) {
			matriz[jugador.f][jugador.c-1] = terreno[3];
			matriz[jugador.f][jugador.c-2] = terreno[8];
			matriz[jugador.f][jugador.c-3] = terreno[15];
			matriz[jugador.f+1][jugador.c] = terreno[1];
			matriz[jugador.f+1][jugador.c-1] = terreno[2];
			matriz[jugador.f+1][jugador.c-2] = terreno[7];
			matriz[jugador.f+1][jugador.c-3] = terreno[14];
			matriz[jugador.f+2][jugador.c] = terreno[4];
			matriz[jugador.f+2][jugador.c-1] = terreno[5];
			matriz[jugador.f+2][jugador.c-2] = terreno[6];
			matriz[jugador.f+2][jugador.c-3] = terreno[13];
			matriz[jugador.f+3][jugador.c] = terreno[9];
			matriz[jugador.f+3][jugador.c-1] = terreno[10];
			matriz[jugador.f+3][jugador.c-2] = terreno[11];
			matriz[jugador.f+3][jugador.c-3] = terreno[12];
		} else if(jugador.brujula == noroeste) {
			matriz[jugador.f][jugador.c-1] = terreno[1];
			matriz[jugador.f][jugador.c-2] = terreno[4];
			matriz[jugador.f][jugador.c-3] = terreno[9];
			matriz[jugador.f-1][jugador.c] = terreno[3];
			matriz[jugador.f-1][jugador.c-1] = terreno[2];
			matriz[jugador.f-1][jugador.c-2] = terreno[5];
			matriz[jugador.f-1][jugador.c-3] = terreno[10];
			matriz[jugador.f-2][jugador.c] = terreno[8];
			matriz[jugador.f-2][jugador.c-1] = terreno[7];
			matriz[jugador.f-2][jugador.c-2] = terreno[6];
			matriz[jugador.f-2][jugador.c-3] = terreno[11];
			matriz[jugador.f-3][jugador.c] = terreno[15];
			matriz[jugador.f-3][jugador.c-1] = terreno[14];
			matriz[jugador.f-3][jugador.c-2] = terreno[13];
			matriz[jugador.f-3][jugador.c-3] = terreno[12];
		}
}

ubicacion Casilla(char caracter, ubicacion ubi,Sensores sensores) {
	ubicacion casilla;
	int c = 0;
	int f = 0;
	int pos = -1;
	for(int i = 1; i < 16; i++) {
		if(sensores.superficie[i] == caracter) pos = i;
	}

	if(pos!= -1) {
		if(ubi.brujula == norte) {
			if (pos >= 1 and pos <= 3) f = -1;
			else if(pos >= 4 and pos < 9) f = -2;
			else f = -3;
		} else if(ubi.brujula == este) {
			if(pos == 15) f = 3;
			else if(pos == 14 or pos == 8 ) f = +2;
			else if(pos == 3 or pos == 7 or pos == 13) f = 1;
			else if(pos == 1 or pos == 5 or pos == 11 ) f = -1;
			else if(pos == 4 or pos == 10) f = -2;
			else if (pos == 9) f = -3;
			else f = 0;
		} else if(ubi.brujula== sur) {
			if(pos >0 and pos <= 3) f = 1;
			else if (pos > 3 and pos< 9) f = 2;
			else f = 3;
		} else if(ubi.brujula == oeste){
			if(pos == 15) f = -3;
			else if(pos == 14 or pos == 8 ) f = -2;
			else if(pos == 3 or pos == 7 or pos == 13) f = -1;
			else if(pos == 1 or pos == 5 or pos == 11 ) f = 1;
			else if(pos == 4 or pos == 10) f = 2;
			else if (pos == 9) f = 3;
			else f = 0;
		}
		if(ubi.brujula == norte) {
			if(pos == 15) c = 3;
			else if(pos == 14 or pos == 8 ) c = +2;
			else if(pos == 3 or pos == 7 or pos == 13) c = 1;
			else if(pos == 1 or pos == 5 or pos == 11 ) c = -1;
			else if(pos == 4 or pos == 10) c = -2;
			else if (pos == 9) c = -3;
			else c = 0;
		} else if(ubi.brujula == este) {
			if (pos >= 1 and pos <= 3) c = 1;
			else if(pos >= 4 and pos < 9) c = 2;
			else c = 3;
		} else if(ubi.brujula== sur) {
			if(pos == 15) c = -3;
			else if(pos == 14 or pos == 8 ) c = -2;
			else if(pos == 3 or pos == 7 or pos == 13) c = -1;
			else if(pos == 1 or pos == 5 or pos == 11 ) c = 1;
			else if(pos == 4 or pos == 10) c = 2;
			else if (pos == 9) c = 3;
			else c = 0;
		} else if(ubi.brujula == oeste) {
			if (pos >= 1 and pos <= 3) c = -1;
			else if(pos >= 4 and pos < 9) c = -2;
			else c = -3;
		}
	}
	casilla.f = ubi.f + f;
	casilla.c = ubi.c +c;
	return casilla;
}

ubicacion BuscarRecargaCercana(const stateN3& c_state,vector<ubicacion> recargas) {
	int min = HeuristicaManhattan(c_state.jugador,recargas[0]);
	ubicacion cercana = recargas[0];
	for(int i = 1; i < recargas.size(); i++) {
		int coste = HeuristicaManhattan(c_state.jugador,recargas[0]);
		if(min > coste) {
			min = coste;
			cercana = recargas[0];
		}
	}
	return cercana;
}

ubicacion CalcularNuevaPosicion(vector<unsigned char> ultima, vector<unsigned char> actual,ubicacion lastUbi) 
{
	ubicacion nuevaUbicacion;
	int destinoEmpujon;
	int posiblesDestinosEncontrados = 0;

	int falloEncontrado = false;
	if(ultima[1]==actual[2] and ultima[2]==actual[3]) {
		for(int i = 4; i <= 7; i++) {
			if(ultima[i] != actual[i+1]) {
				falloEncontrado = true;
			}
		}
		for(int i = 9; i <= 14; i++) {
			if(ultima[i] != actual[i+1]) {
				falloEncontrado = true;
			}
		}

		if(!falloEncontrado) {
			posiblesDestinosEncontrados++;
			destinoEmpujon = 4; //izquierda
		}
	}

	falloEncontrado = false;
	if(ultima[4]==actual[1] and ultima[5]==actual[2] and ultima[6]==actual[3]) {
		for(int i = 9; i <= 13;i++) {
			if(ultima[i] != actual[i-5]) {
				falloEncontrado = true;
			}
		}
		if(!falloEncontrado) {
			posiblesDestinosEncontrados++;
			destinoEmpujon = 1; //izquierda arriba
		}
	}

	falloEncontrado = false;
	if(ultima[5]==actual[1] and ultima[6]==actual[2] and ultima[7]==actual[3]) {
		for(int i = 10; i <= 14; i++) {
			if(ultima[i] != actual[i-6]) {
				falloEncontrado = true;
			}
		}
		if(!falloEncontrado) {
			posiblesDestinosEncontrados++;
			destinoEmpujon = 2; //arriba
		}
	}

	falloEncontrado = false;
	if(ultima[6]==actual[1] and ultima[7]==actual[2] and ultima[8]==actual[3]) {
		for(int i = 11; i<= 15; i++) {
			if(ultima[i] != actual[i-7]) {
				falloEncontrado = true;
			}
		}

		if(!falloEncontrado) {
			posiblesDestinosEncontrados++;
			destinoEmpujon = 3; //derecha arriba
		}
	}

	falloEncontrado = false;
	if(ultima[2] == actual[1] and ultima[3]==actual[2]) {
		for(int i = 5; i <= 8; i++) {
			if(ultima[i] != actual[i-1]) {
				falloEncontrado = true;
			}
		}

		for(int i = 10; i <= 15; i++) {
			if(ultima[i] != actual[i-1]) {
				falloEncontrado = true;
			}
		}
		if(!falloEncontrado) {
			posiblesDestinosEncontrados++;
			destinoEmpujon = 5; //derecha
		}
	}

	falloEncontrado = false;
	if(ultima[0] == actual[3]) {
		for(int i = 1; i <= 3; i++) {
			if(ultima[i] != actual[i+5]) {
				falloEncontrado = true;
			}
		}
		for(int i = 4; i <= 8; i++) {
			if(ultima[i] != actual[i+7]) {
				falloEncontrado = true;
			}
		}
		if(!falloEncontrado) {
			posiblesDestinosEncontrados++;
			destinoEmpujon = 6; //izquierda abajo
		}
	}

	falloEncontrado = false;
	if(ultima[0] == actual[2]) {
		for(int i = 1; i <= 3; i++) {
			if(ultima[i] != actual[i+4]) {
				falloEncontrado = true;
			}
		}
		for(int i = 4; i <= 8; i++) {
			if(ultima[i] != actual[i+6]) {
				falloEncontrado = true;
			}
		}
		if(!falloEncontrado) {
			posiblesDestinosEncontrados++;
			destinoEmpujon = 7; // abajo
		}
	}

	falloEncontrado = false;
	if(ultima[0] == actual[1]) {
		for(int i = 1; i <= 3; i++) {
			if(ultima[i] != actual[i+3]) {
				falloEncontrado = true;
			}
		}
		for(int i = 4; i <= 8; i++) {
			if(ultima[i] != actual[i+5]) {
				falloEncontrado = true;
			}
		}
		if(!falloEncontrado) {
			posiblesDestinosEncontrados++;
			destinoEmpujon = 8; // derecha abajo
		}
	}

	falloEncontrado = false;
	for(int i = 0; i < 16; i++) {
		if(ultima[i] != actual[i]) {
			falloEncontrado = true;
		}
	}
	if(!falloEncontrado) {
		posiblesDestinosEncontrados++;
		destinoEmpujon = 0; // no empujado
	}

	if(posiblesDestinosEncontrados == 1) {
		nuevaUbicacion = CalcularDestino(destinoEmpujon,lastUbi);
	} else {
		nuevaUbicacion.f = -1;
		nuevaUbicacion.c= -1;
		nuevaUbicacion.brujula = norte;
	}
	return nuevaUbicacion;
}

ubicacion CalcularDestino(int n, ubicacion lastUbi) {
	ubicacion ubi;
	ubi.f = lastUbi.f;
	ubi.c = lastUbi.c;
	ubi.brujula = lastUbi.brujula;
	switch(n) {
		case 0:
			return lastUbi;
		break;
		case 1:
			if(lastUbi.brujula == norte) {ubi.f--; ubi.c--;}
			else if(lastUbi.brujula == este) {ubi.f--; ubi.c++;}
			else if(lastUbi.brujula == sur) {ubi.f++; ubi.c++;}
			else if(lastUbi.brujula == oeste) {ubi.f++; ubi.c--;}
		break;
		case 2:
			if(lastUbi.brujula == norte) {ubi.f--;}
			else if(lastUbi.brujula == este) {ubi.c++;}
			else if(lastUbi.brujula == sur) {ubi.f++;}
			else if(lastUbi.brujula == oeste) {ubi.c--;}
		break;
		case 3:
			if(lastUbi.brujula == norte) {ubi.f--; ubi.c++;}
			else if(lastUbi.brujula == este) {ubi.f++; ubi.c++;}
			else if(lastUbi.brujula == sur) {ubi.f++; ubi.c--;}
			else if(lastUbi.brujula == oeste) {ubi.f--; ubi.c--;}
		break;
		case 4:
			if(lastUbi.brujula == norte) {ubi.c--;}
			else if(lastUbi.brujula == este) {ubi.f--;}
			else if(lastUbi.brujula == sur) {ubi.c++;}
			else if(lastUbi.brujula == oeste) {ubi.f++;}
		break;
		case 5:
			if(lastUbi.brujula == norte) {ubi.c++;}
			else if(lastUbi.brujula == este) {ubi.f++;}
			else if(lastUbi.brujula == sur) {ubi.c--;}
			else if(lastUbi.brujula == oeste) {ubi.f--;}
		break;
		case 6:
			if(lastUbi.brujula == norte) {ubi.f++; ubi.c--;}
			else if(lastUbi.brujula == este) {ubi.f--; ubi.c--;}
			else if(lastUbi.brujula == sur) {ubi.f--; ubi.c++;}
			else if(lastUbi.brujula == oeste) {ubi.f++; ubi.c++;}
		break;
		case 7:
			if(lastUbi.brujula == norte) {ubi.f++;}
			else if(lastUbi.brujula == este) {ubi.c--;}
			else if(lastUbi.brujula == sur) {ubi.f--;}
			else if(lastUbi.brujula == oeste) {ubi.c++;}
		break;
		case 8:
			if(lastUbi.brujula == norte) {ubi.f++; ubi.c++;}
			else if(lastUbi.brujula == este) {ubi.f++; ubi.c--;}
			else if(lastUbi.brujula == sur) {ubi.f--; ubi.c--;}
			else if(lastUbi.brujula == oeste) {ubi.f--; ubi.c++;}
		break;
	}
	return ubi;
}