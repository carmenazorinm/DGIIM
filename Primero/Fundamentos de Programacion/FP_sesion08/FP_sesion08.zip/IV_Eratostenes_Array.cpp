/* FUNDAMENTOS DE LA PROGRAMACION
	
	Carmen Azor�n Mart� Grupo 2.2. 
	
	Matem�ticas e Ingenier�a Inform�tica
	
	Ejercicio 14: el programa lee un numero y muestra todos los numeros primos
	menores o iguales que �ste. Para ello crea un vector primos[50001] en el 
	que se guardaran datos de tipo bool. Al principio, todos van a ser true, 
	pero se ir�n modificando para que solo quede true en las posiciones primas.
*/

#include<iostream> //inclusion de recursos de E/S

using namespace std;

int main(){
	
	int n;
	
	//entrada de datos
	
	cout<<endl;
	
	do{
		cout<< " Introduzca el valor positivo hasta el ";
		cout<<"que se quieren conocer los primos: ";
		cin>> n;
	}while(n<=0 || n>5000);
	
	//calculos
	
	const int LIMITE = 5000+1; //el numero de casillas que tendr� el vector 
	bool primos[LIMITE];
	primos[0] = false; //el 0 no es primo
	for(int i = 1; i < LIMITE; i++) //en todas las casillas se introducir� true
		primos[i] = true;
		
	int primo = 1;	
	
	//va a pasar numero por numero del vector comprobando si en su casilla est�
	//introducido true o false. 
	
	while(primo < LIMITE-1 && primo*primo < LIMITE){//ponemos LIMITE-1 porque  
											//la siguiente instruccion es sumar 
											//+1 y no puede correr la ultima   
											//casilla del vector
		primo++;
		bool es_primo = primos[primo];
		if(es_primo){//si el numero de la posicion es true, es decir, prima
		
		//va a ir pasando a partir del numero de la casilla siguiente a la del 
		//primo, porque el primo siempre va a ser divible por si mismo. 
		//Va casilla por casilla y si el numero de la casilla es multiplo
		//del primo, entonces en su posicion se introduce false. 
			for(int i = primo+1; i < LIMITE; i++){
				if(i%primo == 0)
					primos[i] = false;
			}
		}
	}
		
	//salida
	cout<<endl;
	cout<< " Los numeros primos menores o iguales que " << n << " son:";
	for(int j = 0; j <= n; j++){
		if(primos[j])
			cout<< " " << j;
	}
	cout<< endl<< endl;
	
	return 0;
}
