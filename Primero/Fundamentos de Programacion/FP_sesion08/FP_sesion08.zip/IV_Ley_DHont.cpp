/* FUNDAMENTOS DE LA PROGRAMACION
	
	Carmen Azor�n Mart� Grupo 2.2. 
	
	Matem�ticas e Ingenier�a Inform�tica
	
	Ejercicio 12: el programa pide un total de esca�os y de partidos. Para cada
	partido crear� un vector que contenga su total de votos, su total de 
	esca�osy su cociente. Estos dos ultimos vectores se ir�n actualizando para
	poder encontrar cu�ntos esca�os le pertenecen a cada partido, soluci�n que
	se mostrar� al final del programa. 
*/

#include<iostream> //inclusion de recursos de E/S

using namespace std;

int main(){

	int TOTAL_ESCANIOS;
	int TOTAL_PARTIDOS;
	
	//entrada de datos
	cout<<endl;
	cout<< " Introduzca el total de escanios a repartir: ";
	cin>>TOTAL_ESCANIOS;
	cout<< " Introduzca el total de partidos que se presentan: ";
	cin>> TOTAL_PARTIDOS;
	
	int votos_partido[TOTAL_PARTIDOS];
	int escanios_partido[TOTAL_PARTIDOS];
	int cociente_partido[TOTAL_PARTIDOS];
	
	for(int i = 0; i < TOTAL_PARTIDOS; i++){	
		cout<< " Introduca el total de votos del partido "<< i+1 << ": ";
		cin>> votos_partido[i];
		escanios_partido[i] = 0;
		cociente_partido[i] = votos_partido[i];
		//para calcular el cociente tendr�a que dividir los votos de partido
		//entre (escanios_partido[i]+1). Pero como he puesto que los esca�os
		//que le pertenecen a cada partido es 0, es como si se dividiese 
		//entre 1. As� que el cociente es = que los votos de cada partido.
	}
	
	//calculos
	
	//voy esca�o por esca�o. En cada esca�o busco cual es el partido con el 
	//mayor cociente y guardo su posicion. A continuaci�n, le sumo un esca�o a 
	//ese partido y actualizo su cociente. 
		
	for(int l = 0; l < TOTAL_ESCANIOS; l++){
		int mayor_cociente = cociente_partido[0];
		int partido_mayor_cociente = 0;
		
		for(int j = 0; j < TOTAL_PARTIDOS; j++){
			if(cociente_partido[j] > mayor_cociente){
				mayor_cociente = cociente_partido[j];
				partido_mayor_cociente = j;
			}
		}
		escanios_partido[partido_mayor_cociente]++;
		cociente_partido[partido_mayor_cociente] = 
			votos_partido[partido_mayor_cociente]
			/(escanios_partido[partido_mayor_cociente]+1);
	}
	
	//salida
	
	for(int m = 0; m < TOTAL_PARTIDOS; m++){
		cout<<endl;
		cout<< " EL partido "<< m+1 << " ha conseguido " << escanios_partido[m];
		cout<< " escanios.";
		cout<<endl;
	}
	cout<<endl;
	
	return 0;
}
