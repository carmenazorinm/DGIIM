Proyecto para producir informes atractivos por pantalla. Se irán ampliando las funciones sucesivamente
